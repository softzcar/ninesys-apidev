<?php

const CK = "ck_3142398030de80ac909743b6b2c81cec2a23ab62";
const CS = "cs_8341cbae22ebbf4ecfe86fac9d2ff6db54042c97";
// const URL = "https://nineteengreen.com";
const URL = "https://dev.nineteengreen.com";
const URLWP = "https://";
const URLWC = "https://";