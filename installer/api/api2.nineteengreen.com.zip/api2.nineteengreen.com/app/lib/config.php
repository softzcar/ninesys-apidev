<?php
/**
 * 
 * CONFIGURACION DELS SITEMA
 * 
 */



/** Woocommerce ninesys */
 define("BASE_URL", 'https://nineteengreen.com/wp-json/');
 
// define("WC_CK",'ck_24e3f33eac53e7b7139a5b260360d966726038a6');
// define("WC_CS",'cs_a79cc6b9117167d2704e6f33b18c7e19afa4f337');

// Nueva valve 
define("WC_CK", 'ck_ec5fc4895b5a80f14a1ab0e729e671b6a23716de');
define("WC_CS", 'cs_f5150117f34e0d91cf0a48a0d064cc426990fd21'); 



/** Local API */
define("LOCAL_API","http://apitmp.nineteensport.loc/");

/** Ping DIR */
define("PING_URL","nineteengreen.com");

/** Localhost PDO Data Connection */
// define("LOCAL_DSN", 'mysql:host=Localhost;dbname=ninesys');
/* define("LOCAL_DSN", 'mysql:host=localhost;dbname=ninesys');
define("LOCAL_USER",'root');
define("LOCAL_PASS",''); */

/* Mocha COnnection 
define("LOCAL_DSN", 'mysql:host=mysql1006.mochahost.com;dbname=softzcar_ninesys');
define("LOCAL_USER", 'softzcar_ninesys');
define("LOCAL_PASS", 'N1n3.515'); 
*/

// SiteGround Connection
// define("LOCAL_DSN", 'mysql:host=localhost;dbname=dbqaht6qrlkgcz'); // ninesys
/* define("LOCAL_DSN", 'mysql:host=localhost;dbname=dbenu27gvq3me6'); // ninesys_2
define("LOCAL_USER", 'ucohxutexwkfg');
define("LOCAL_PASS", 'N1n3Sys.21$'); */

// Mocha Connection
// define("LOCAL_DSN", 'mysql:host=localhost;dbname=dbqaht6qrlkgcz'); // ninesys
define("LOCAL_DSN", 'mysql:host=mocha3036.mochahost.com;dbname=appzone_ninesys_app'); // ninesys_2
define("LOCAL_USER", 'appzone_ninesys');
define("LOCAL_PASS", '5105_sql_nine');


