<?php

/**
 * llamdas a Woocomemrce
 */

use Automattic\WooCommerce\Client;

class WooMe
{
    private $url = "https://dev.nineteengreen.com";
    private $ck  = "ck_3142398030de80ac909743b6b2c81cec2a23ab62";
    private $cs  = "cs_8341cbae22ebbf4ecfe86fac9d2ff6db54042c97";
    private $opt = ['version' => 'wc/v3'];
    private $woocommerce;

    public function __construct()
    {
        $this->woocommerce = new Client($this->url, $this->ck, $this->cs, $this->opt);
    }

    /**
     * INICIO PRODUCTOS
     */
    public function getProductById($id)
    {
        // $woocommerce  = new Client($this->url, $this->ck, $this->cs, $this->opt);
        $endpoint = 'products/' . $id;
        $response = $this->woocommerce->get($endpoint);

        return $response;
    }

    public function getAllProducts()
    {
        $ban = true;

        $page     = 1;
        $endpoint = 'products?per_page=100&page=';
        $resp     = array();

        while ($ban) {
            $tmp = $this->woocommerce->get($endpoint . $page);

            if (!empty($tmp)) {
                for ($i = 0; $i < count($tmp); $i++) {
                    $obj["id"]             = $tmp[$i]->id;
                    $obj["sku"]            = $tmp[$i]->sku;
                    $obj["name"]           = $tmp[$i]->name;
                    $obj["stock_quantity"] = $tmp[$i]->stock_quantity;
                    $obj["price"]          = $tmp[$i]->price;
                    $obj["regular_price"]  = $tmp[$i]->regular_price;
                    $obj["sale_price"]     = $tmp[$i]->sale_price;
                    $obj["permalink"]      = $tmp[$i]->permalink;
                    $obj["images"]         = $tmp[$i]->images;

                    if (empty($obj["images"])) {
                        $obj["images"] = "https://nineteengreen.com/wp-content/uploads/woocommerce-placeholder-350x350.png";
                    } else {
                        $obj["images"] = $tmp[$i]->images[0]->src;
                    }

                    $resp[] = $obj;
                }
                $page++;
            } else {
                $ban = false;
            }
        }

        return json_encode($resp);
    }

    public function createProduct($name, $sku, $regular_price, $stock_quantity, $categories, $sizes)
    {
        // Verificar name
        if (trim(strlen($name)) === 0) {
            $name = "Asigne un nombre";
        }

        // Verificar price
        $regular_price = str_replace(",", ".", $regular_price);
        if (!is_numeric($regular_price)) {
            $regular_price = 0.0;
        }

        // Verificar Cantidad
        if (is_numeric($stock_quantity)) {
            $stock_quantity = intval($stock_quantity);
        } else {
            $stock_quantity = 0;
        }

        // PROCESAR LAS CATEGORIAS
        $myCategories = array();

        $arrayCat = explode(",", $categories);
        if (count($arrayCat) === 0) {
            $myCategories[] = ['id' => $categories];
        } else {
            foreach ($arrayCat as $key => $value) {
                $myCategories[] = ['id' => $value];
            }
        }

        // PROCESAR LAS TALLAS
        $mySizes = array();

        $arraySiz = explode(",", $sizes);
        if (count($arraySiz) === 0) {
            $mySizes[] = [
                'id'      => 2,
                'name'    => "Talla",
                'visible' => true,
                'options' => $sizes,
            ];
        } else {
            foreach ($arraySiz as $key => $value) {
                $tmp[] = $value;
            }

            $mySizes[] = [
                'id'      => 2,
                'name'    => "Talla",
                'visible' => true,
                'options' => $tmp,
            ];
        }

        // Crear vector de datos delprodcuto
        $data = [
            'name'              => $name,
            'sku'               => $sku,
            'stock_quantity'    => $stock_quantity,
            'manage_stock'      => true,
            'regular_price'     => $regular_price,
            'type'              => 'simple',
            'description'       => '',
            'short_description' => '',
            'categories'        => $myCategories,
            'attributes'        => $mySizes,
            'images'            => [
                [
                    'src' => 'https://nineteengreen.com/wp-content/uploads/woocommerce-placeholder-350x350.png',
                ],
            ],
        ];

        return json_encode($this->woocommerce->post('products', $data));
    }

    public function createProductLite($name, $regular_price)
    {
        // return "<br>name: " . $name . "price: " . $regular_price;

        // Verificar name
        if (trim(strlen($name)) === 0) {
            $name = "Asigne un nombre";
        }

        // Verificar price
        $regular_price = str_replace(",", ".", $regular_price);
        if (!is_numeric($regular_price)) {
            $regular_price = 0.0;
        }

        // Crear vector de datos delprodcuto
        $data = [
            'name'           => $name,
            'sku'            => "",
            'regular_price'  => $regular_price,
            'stock_quantity' => 0,
            'images'         => [
                [
                    'src' => 'https://nineteengreen.com/wp-content/uploads/woocommerce-placeholder-350x350.png',
                ],
            ],
        ];
        return json_encode($this->woocommerce->post('products', $data));
    }

    // Actualizar productos
    public function updateProduct($id, $name, $regular_price, $stock_quantity)
    {
        $data = [
            'name'           => $name,
            'stock_quantity' => $stock_quantity,
            'manage_stock'   => true,
            'regular_price'  => $regular_price,
        ];

        return json_encode($this->woocommerce->put('products/' . $id, $data));
    }

    // Actualizar Stock (Cantidad de prodcuto)
    public function updateProductStock($id, $stock_quantity)
    {
        $data = [
            'stock_quantity' => $stock_quantity,
            'manage_stock'   => true,
        ];
        return json_encode($this->woocommerce->put('products/' . $id, $data));
    }

    // Eliminar Producto
    public function deleteProduct($id)
    {
        return json_encode($this->woocommerce->delete('products/' . $id, ['force' => true]));
    }
    /**
     * FIN PRODUCTOS
     */

    /**
     * INICIO CLIENTES
     */
    public function getCustomerById($id)
    {
        // $woocommerce  = new Client($this->url, $this->ck, $this->cs, $this->opt);
        $endpoint = 'customers/' . $id;
        $response = $this->woocommerce->get($endpoint);

        return $response;
    }

    public function getAllCustomesrs()
    {
        $ban = true;

        $page     = 1;
        $endpoint = 'customers?per_page=100&page=';
        $resp     = array();

        while ($ban) {
            $tmp = $this->woocommerce->get($endpoint . $page);

            if (!empty($tmp)) {
                for ($i = 0; $i < count($tmp); $i++) {
                    $obj["id"]         = $tmp[$i]->id;
                    $obj["first_name"] = $tmp[$i]->first_name;
                    $obj["last_name"]  = $tmp[$i]->last_name;
                    $obj["role"]       = $tmp[$i]->role;
                    $obj["username"]   = $tmp[$i]->username;
                    $obj["cedula"]     = $tmp[$i]->billing->postcode;
                    $obj["address"]    = $tmp[$i]->billing->address_1;
                    $obj["phone"]      = $tmp[$i]->billing->phone;
                    $obj["email"]      = $tmp[$i]->email;

                    $resp[] = $obj;
                }
                $page++;
            } else {
                $ban = false;
            }
        }

        return json_encode($resp);
    }

    public function createCustomer($first_name, $last_name, $cedula, $phone, $email, $address)
    {
        // Generar username alearotio
        $bytes    = random_bytes(6);
        $token    = bin2hex($bytes);
        $username = $first_name . $token;

        // Verificar email
        if ($email === "none") {
            $email = "none_" . $token . "@email.com";
        }

        if ($phone === "none") {
            $phone = "";
        }

        if ($address === "none") {
            $address = "";
        }

        // Generar username alearotio
        $bytes    = random_bytes(6);
        $token    = bin2hex($bytes);
        $username = $first_name . $token;

        // Crear vector de datos del cliente
        $data = [
            'email'      => $email,
            'first_name' => $first_name,
            'last_name'  => $last_name,
            'username'   => $username,
            'billing'    => [
                'first_name' => $first_name,
                'last_name'  => $last_name,
                'company'    => '',
                'address_1'  => $address,
                'address_2'  => '',
                'city'       => 'El Vigía',
                'state'      => 'MRD',
                'postcode'   => $cedula,
                'country'    => 'VE',
                'email'      => $email,
                'phone'      => $phone,
            ],
            'shipping'   => [
                'first_name' => $first_name,
                'last_name'  => $last_name,
                'company'    => '',
                'address_1'  => 'Venezuela',
                'address_2'  => '',
                'city'       => 'El Vigía',
                'state'      => 'MRD',
                'postcode'   => $cedula,
                'country'    => 'VE',
            ],
        ];

        $data2 = [
            'email'      => $email,
            'first_name' => 'John',
            'last_name'  => 'Doe',
            'username'   => $username,
            'billing'    => [
                'first_name' => 'John',
                'last_name'  => 'Doe',
                'company'    => '',
                'address_1'  => '969 Market',
                'address_2'  => '',
                'city'       => 'San Francisco',
                'state'      => 'CA',
                'postcode'   => '94103',
                'country'    => 'US',
                'email'      => 'john.doe@example.com',
                'phone'      => '(555) 555-5555',
            ],
            'shipping'   => [
                'first_name' => 'John',
                'last_name'  => 'Doe',
                'company'    => '',
                'address_1'  => '969 Market',
                'address_2'  => '',
                'city'       => 'San Francisco',
                'state'      => 'CA',
                'postcode'   => '94103',
                'country'    => 'US',
            ],
        ];

        // return json_encode($data);
        return json_encode($this->woocommerce->post('customers/', $data));
    }

    public function updateCustomer($id, $first_name, $last_name, $cedula, $phone, $email, $address)
    {
        $data = [
            'first_name' => $first_name,
            'last_name'  => $last_name,
            'billing'    => [
                'postcode'  => $cedula,
                'phone'     => $phone,
                'address_1' => $address,
            ],
            'email'      => $email,
        ];

        return json_encode($this->woocommerce->put('customers/' . $id, $data));
    }
    /**
     * FIN CLIENTES
     */

    /**
     * CATEGORIAS
     */
    public function getAllCategories()
    {
        $endpoint = 'products/categories/?per_page=100';
        $response = $this->woocommerce->get($endpoint);

        return json_encode($response);
    }
    /**
     * FIN CATEGORIAS
     */

    /**
     * ATRIBUTOS
     */
    public function getAllAttributes()
    {
        $endpoint = 'products/attributes/';
        $response = $this->woocommerce->get($endpoint);

        return json_encode($response);
    }
    /**
     * FIN ATRIBUTOS
     */

    /**
     * TALLAS
     */
    public function getSizes()
    {
        $endpoint = 'products/attributes/2/terms?per_page=40';
        $response = $this->woocommerce->get($endpoint);

        return json_encode($response);
    }
    /**
     * FIN TALLAS
     */
}
