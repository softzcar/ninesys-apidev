/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.13-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: api_emp_174
-- ------------------------------------------------------
-- Server version	10.11.13-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `abonos`
--

DROP TABLE IF EXISTS `abonos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `abonos` (
  `_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID de la talba',
  `id_orden` int(11) DEFAULT NULL COMMENT 'ID de la orden',
  `id_empleado` int(11) DEFAULT NULL COMMENT 'ID del empleado',
  `abono` decimal(12,2) NOT NULL DEFAULT 0.00,
  `descuento` decimal(12,2) DEFAULT 0.00,
  `nota_credito` decimal(12,2) DEFAULT 0.00,
  `detalle` varchar(60) DEFAULT NULL COMMENT 'Descripción del abono',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha del abono',
  PRIMARY KEY (`_id`),
  KEY `id_orden` (`id_orden`,`id_empleado`),
  KEY `id_empleado` (`id_empleado`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Abonos realizados a órdenes. Registra pagos parciales efectuados por clientes para reducir el saldo pendiente de una orden.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abonos`
--

LOCK TABLES `abonos` WRITE;
/*!40000 ALTER TABLE `abonos` DISABLE KEYS */;
INSERT INTO `abonos` VALUES
(1,1,606,100.00,0.00,0.00,NULL,'2026-02-27 16:33:04'),
(2,2,606,100.00,0.00,0.00,NULL,'2026-02-27 16:33:19'),
(3,3,606,100.00,0.00,0.00,NULL,'2026-02-27 16:33:22'),
(4,4,606,100.00,0.00,0.00,NULL,'2026-02-27 16:33:24'),
(5,5,606,100.00,0.00,0.00,NULL,'2026-02-27 16:33:26'),
(6,6,606,100.00,0.00,0.00,NULL,'2026-02-27 16:33:28'),
(7,7,606,100.00,0.00,0.00,NULL,'2026-02-27 16:33:29'),
(8,8,606,100.00,0.00,0.00,NULL,'2026-02-27 16:33:32'),
(9,9,606,100.00,0.00,0.00,NULL,'2026-02-27 16:33:34');
/*!40000 ALTER TABLE `abonos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aprobacion_clientes`
--

DROP TABLE IF EXISTS `aprobacion_clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aprobacion_clientes` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_orden` int(11) DEFAULT NULL,
  `id_diseno` int(11) DEFAULT NULL,
  `check` tinyint(1) NOT NULL DEFAULT 1,
  `moment` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`_id`),
  KEY `id_orden` (`id_orden`,`id_diseno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Registro para notificación de aprobación de diseño';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aprobacion_clientes`
--

LOCK TABLES `aprobacion_clientes` WRITE;
/*!40000 ALTER TABLE `aprobacion_clientes` DISABLE KEYS */;
/*!40000 ALTER TABLE `aprobacion_clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asistencias`
--

DROP TABLE IF EXISTS `asistencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `asistencias` (
  `_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID unico del registro',
  `id_empleado` int(11) DEFAULT NULL COMMENT 'ID del empleado',
  `registro` varchar(14) DEFAULT NULL COMMENT 'Entrada Mañana, Salida Mañana, Entrada Tarde, Salida Tarde',
  `detalle` mediumtext DEFAULT NULL COMMENT 'Detalle de el registro si se requiere',
  `moment` datetime DEFAULT current_timestamp() COMMENT 'Momento de la acción',
  PRIMARY KEY (`_id`),
  KEY `id_empleado` (`id_empleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Registro de control de asistencia de empleados. Almacena entradas y salidas con timestamp para reportes semanales y cálculo de horas trabajadas.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asistencias`
--

LOCK TABLES `asistencias` WRITE;
/*!40000 ALTER TABLE `asistencias` DISABLE KEYS */;
/*!40000 ALTER TABLE `asistencias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `caja`
--

DROP TABLE IF EXISTS `caja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `caja` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_caja_cierres` int(11) DEFAULT NULL COMMENT 'ID del cierre de la caja',
  `monto` decimal(12,2) NOT NULL DEFAULT 0.00 COMMENT 'monto de la moneda',
  `moneda` varchar(10) NOT NULL DEFAULT '0' COMMENT 'dolares, pesos, bolivares',
  `tasa` decimal(12,2) NOT NULL DEFAULT 1.00 COMMENT 'tasa de conversion para el dia',
  `detalle` text DEFAULT NULL,
  `tipo` varchar(20) DEFAULT NULL COMMENT 'orden_nueva, orden_abono, otro_abono, retiro, cierre_de_caja, ajuste',
  `id_empleado` int(11) DEFAULT NULL,
  `moment` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`_id`),
  KEY `id_empleado` (`id_empleado`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Registros de los movimientos del efectivo en la caja antes del cierre, luego se reinicia, el histroico de ingresos queda en la tabla metodos_de_pago';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `caja`
--

LOCK TABLES `caja` WRITE;
/*!40000 ALTER TABLE `caja` DISABLE KEYS */;
INSERT INTO `caja` VALUES
(1,NULL,100.00,'Dólares',1.00,'Nueva Orden','orden_nueva',606,'2026-02-27 16:33:04'),
(2,NULL,100.00,'Dólares',1.00,'Nueva Orden','orden_nueva',606,'2026-02-27 16:33:19'),
(3,NULL,100.00,'Dólares',1.00,'Nueva Orden','orden_nueva',606,'2026-02-27 16:33:22'),
(4,NULL,100.00,'Dólares',1.00,'Nueva Orden','orden_nueva',606,'2026-02-27 16:33:24'),
(5,NULL,100.00,'Dólares',1.00,'Nueva Orden','orden_nueva',606,'2026-02-27 16:33:26'),
(6,NULL,100.00,'Dólares',1.00,'Nueva Orden','orden_nueva',606,'2026-02-27 16:33:28'),
(7,NULL,100.00,'Dólares',1.00,'Nueva Orden','orden_nueva',606,'2026-02-27 16:33:29'),
(8,NULL,100.00,'Dólares',1.00,'Nueva Orden','orden_nueva',606,'2026-02-27 16:33:32'),
(9,NULL,100.00,'Dólares',1.00,'Nueva Orden','orden_nueva',606,'2026-02-27 16:33:34');
/*!40000 ALTER TABLE `caja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `caja_cierres`
--

DROP TABLE IF EXISTS `caja_cierres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `caja_cierres` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `dolares` decimal(10,0) NOT NULL DEFAULT 0 COMMENT 'Total recaudado en dólares',
  `pesos` decimal(10,0) NOT NULL DEFAULT 0 COMMENT 'Total recaudado en pesos',
  `bolivares` decimal(10,0) NOT NULL DEFAULT 0 COMMENT 'Total recaudado en bolívares',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha del cierre',
  `id_empleado` int(11) DEFAULT NULL COMMENT 'ID del empleado que realizó el cierre',
  PRIMARY KEY (`_id`),
  KEY `id_empleado` (`id_empleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Historial de cierres de caja. Almacena totales por moneda, empleado responsable del cierre y fecha de corte para conciliación contable.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `caja_cierres`
--

LOCK TABLES `caja_cierres` WRITE;
/*!40000 ALTER TABLE `caja_cierres` DISABLE KEYS */;
/*!40000 ALTER TABLE `caja_cierres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `caja_fondos`
--

DROP TABLE IF EXISTS `caja_fondos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `caja_fondos` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_caja_cierres` int(11) DEFAULT NULL COMMENT 'ID del cierre de la caja',
  `id_empleado` int(11) DEFAULT NULL COMMENT 'ID del Vendedor',
  `dolares` decimal(12,0) NOT NULL DEFAULT 0 COMMENT 'Fondo en dólares',
  `pesos` decimal(12,0) NOT NULL DEFAULT 0 COMMENT 'Fondo en pesos',
  `bolivares` decimal(12,0) NOT NULL DEFAULT 0 COMMENT 'Fondo en bolívares',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha del registro',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Fondo de caja chica. Registra el efectivo base que permanece en caja después de cada cierre para operaciones del siguiente período.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `caja_fondos`
--

LOCK TABLES `caja_fondos` WRITE;
/*!40000 ALTER TABLE `caja_fondos` DISABLE KEYS */;
/*!40000 ALTER TABLE `caja_fondos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogo_impresoras`
--

DROP TABLE IF EXISTS `catalogo_impresoras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `catalogo_impresoras` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_interno` varchar(50) NOT NULL COMMENT 'Identificador único y fácil de leer para el empleado. Ej: SUBLIMACION-01, EPSON-F570-A',
  `marca` varchar(50) DEFAULT NULL COMMENT 'Marca del fabricante. Ej: Epson, Roland',
  `modelo` varchar(100) DEFAULT NULL COMMENT 'Nombre comercial del modelo. Ej: SureColor F570',
  `capacidad_contenedor` decimal(7,2) DEFAULT NULL COMMENT 'Capacidad del contenedor de la tinta',
  `ubicacion` varchar(100) DEFAULT NULL COMMENT 'Ubicación física para ayudar al empleado a identificarla. Ej: Taller de Estampado',
  `tipo_tecnologia` varchar(50) DEFAULT NULL COMMENT 'Tecnología para agrupar o filtrar. Ej: Sublimación, DTG, DTF',
  `estado` varchar(20) NOT NULL DEFAULT 'activa' COMMENT 'Estado actual. Ej: activa, inactiva, en_mantenimiento',
  `notas` text DEFAULT NULL COMMENT 'Cualquier información adicional relevante.',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha de registro',
  PRIMARY KEY (`_id`),
  UNIQUE KEY `idx_codigo_interno` (`codigo_interno`) COMMENT 'Asegura que cada código sea único.'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Catálogo de impresoras de la empresa. Almacena información de equipos de impresión para asignación de trabajos y control de producción.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogo_impresoras`
--

LOCK TABLES `catalogo_impresoras` WRITE;
/*!40000 ALTER TABLE `catalogo_impresoras` DISABLE KEYS */;
INSERT INTO `catalogo_impresoras` VALUES
(1,'IMPRESORA PRINCIPAL','EPSON','EPS_9902',1000.00,'PISO 1','CMYK','activa','Impresora con cabezales originales','2026-01-27 18:53:01'),
(2,'IMPRESORA SECUNDARIA','Mimaki','MK_09890',750.00,'PISO 2','CMYKW','activa','Impresora para usar solo con tintas originales','2026-01-27 18:53:01');
/*!40000 ALTER TABLE `catalogo_impresoras` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogo_insumos_productos`
--

DROP TABLE IF EXISTS `catalogo_insumos_productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `catalogo_insumos_productos` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(128) NOT NULL COMMENT 'Nombre del tipo de insumo',
  `id_product` int(11) NOT NULL COMMENT 'ID del producto (FK a products._id)',
  `id_departamento` int(11) NOT NULL COMMENT 'ID del departamento',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha de registro',
  PRIMARY KEY (`_id`),
  UNIQUE KEY `nombre` (`nombre`),
  UNIQUE KEY `nombre_2` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Catálogo maestro de tipos de insumos para producción. Define categorías de materiales (telas, tintas, botones, etc.) que se asignan a productos.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogo_insumos_productos`
--

LOCK TABLES `catalogo_insumos_productos` WRITE;
/*!40000 ALTER TABLE `catalogo_insumos_productos` DISABLE KEYS */;
INSERT INTO `catalogo_insumos_productos` VALUES
(1,'Papel para sublimación',1,1,'2026-01-27 18:53:01'),
(2,'Tela Atlética',1,3,'2026-01-27 18:53:01'),
(3,'Botones',1,4,'2026-01-27 18:53:01'),
(4,'Tinta',1,1,'2026-01-27 18:53:01'),
(5,'Tela Licra',1,3,'2026-01-27 18:53:01'),
(6,'Tela Algodón',1,3,'2026-01-27 18:53:01'),
(7,'Diseño Gráfico',2,7,'2026-01-27 18:53:01'),
(8,'Tela de franelas',1,2,'2026-02-10 14:26:02');
/*!40000 ALTER TABLE `catalogo_insumos_productos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalogo_telas`
--

DROP TABLE IF EXISTS `catalogo_telas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `catalogo_telas` (
  `_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificador unico de la tabla',
  `tela` varchar(45) DEFAULT NULL COMMENT 'Nombre de la tela',
  `moment` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`_id`),
  UNIQUE KEY `_id` (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Catálogo de telas disponibles. Almacena tipos de tela con características para selección en órdenes de producción.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalogo_telas`
--

LOCK TABLES `catalogo_telas` WRITE;
/*!40000 ALTER TABLE `catalogo_telas` DISABLE KEYS */;
INSERT INTO `catalogo_telas` VALUES
(1,'Tela de Prueba','2025-09-25 16:51:19'),
(2,'Algodon','2026-02-11 20:28:25'),
(3,'Jean','2026-02-11 20:28:33');
/*!40000 ALTER TABLE `catalogo_telas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL COMMENT 'Nombre de la categoría',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Categorías de productos del catálogo. Organiza productos en grupos para clasificación, filtrado y reportes de ventas.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(1,'Categoría de Pruebas');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `check_tareas`
--

DROP TABLE IF EXISTS `check_tareas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `check_tareas` (
  `_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID unico',
  `id_orden` int(11) DEFAULT NULL COMMENT 'ID de la orden',
  `id_lotes_detalles_empleados_asigandos` int(11) DEFAULT NULL COMMENT 'ID del empleado asignado en lotes_detalles',
  `id_ordenes_productos` int(11) DEFAULT NULL COMMENT 'ID del producto de la orden',
  `id_empleado` int(11) DEFAULT NULL COMMENT 'ID del empleado',
  `id_departamento` int(11) DEFAULT NULL COMMENT 'ID del departamento',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fin de tarea',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Lista de verificación de tareas por empleado. Controla el checklist de actividades completadas durante el proceso de producción de cada orden.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `check_tareas`
--

LOCK TABLES `check_tareas` WRITE;
/*!40000 ALTER TABLE `check_tareas` DISABLE KEYS */;
/*!40000 ALTER TABLE `check_tareas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comisiones_pagados`
--

DROP TABLE IF EXISTS `comisiones_pagados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `comisiones_pagados` (
  `_id` int(11) NOT NULL COMMENT 'ID único',
  `id_empleado` int(11) DEFAULT NULL COMMENT 'ID del empleado',
  `tipo_comision` varchar(12) DEFAULT NULL COMMENT 'Tipo de comisión',
  `numero_semana` int(2) DEFAULT NULL COMMENT 'Número de semana',
  `monto` decimal(10,2) DEFAULT NULL COMMENT 'Monto de la comisión',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha de registro'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Registro de comisiones pagadas a empleados. Almacena pagos de comisiones por semana y tipo.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comisiones_pagados`
--

LOCK TABLES `comisiones_pagados` WRITE;
/*!40000 ALTER TABLE `comisiones_pagados` DISABLE KEYS */;
/*!40000 ALTER TABLE `comisiones_pagados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `config` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `app_key` text DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Indica si el cliente tiene acceso a el sitema o está suspendido',
  `nombre_empresa` varchar(45) DEFAULT NULL,
  `identificador_fiscal` varchar(60) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL COMMENT 'Dirección de la empresa',
  `telefonos` int(60) DEFAULT NULL COMMENT 'Teléfonos de la empresa',
  `email` int(255) DEFAULT NULL COMMENT 'Email de la empresa',
  `msg_welcome` text DEFAULT NULL COMMENT 'Mensaje de bienvenida a el cliente',
  `msg_bye` text DEFAULT NULL COMMENT 'Mensajde de despedida al cliente',
  `msg_saldo` text DEFAULT NULL COMMENT 'Mensaje de saldo pendiente del cliente',
  `sys_mostrar_detalle_terminar_indicidual` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Indica si se muestra el formaulario de ingresar detalle de la terminación del item indicidual en el módulo de empleados al momento de terminar una tarea individual',
  `sys_mostrar_rollo_en_empleado_corte` tinyint(1) DEFAULT 0 COMMENT 'Muestra la opción sedeleccionar rollo en el módulo de empleados depatament de Corte',
  `sys_mostrar_rollo_en_empleado_estampado` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Mostrar el rollo de tela al emplado de Estampado',
  `sys_mostrar_insumo_en_empleado_costura` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Mostrar select de insumos en modulo de empleados',
  `sys_mostrar_insumo_en_empleado_limpieza` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'empleados',
  `sys_mostrar_insumo_en_empleado_revision` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'empleados',
  `sys_comision_de_costura` varchar(8) NOT NULL DEFAULT 'producto' COMMENT 'Define si a costura se le calclua comision por el porcentaje en la tabla empleados o el porcentaje ne la tabla productos',
  `multiplicador_precio` decimal(5,2) NOT NULL DEFAULT 0.00 COMMENT 'Multiplicador de precio predeterminado para conversión USD a VES',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Configuración general de la empresa. Almacena parámetros del sistema como datos fiscales, mensajes de WhatsApp, opciones de visualización en módulos y tipo de comisión.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES
(1,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,1,0,0,0,'producto',0.00);
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(60) DEFAULT NULL,
  `last_name` varchar(60) DEFAULT NULL,
  `username` varchar(60) DEFAULT NULL,
  `cedula` varchar(12) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `billing_city` varchar(60) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha de registro',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Registro de clientes. Almacena datos de contacto (nombre, cédula, teléfono, email, dirección) para facturación y comunicación.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES
(1,'Cliente','de Pruebas','Cliente Prueba','V12345678','Dirección de prueba','Caracas','584240000000','clientepruebas@email.com','2026-02-27 16:26:51');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departamentos`
--

DROP TABLE IF EXISTS `departamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `departamentos` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_modulo` int(11) DEFAULT NULL COMMENT 'ID del módulo asignado al departamento',
  `orden_proceso` int(11) NOT NULL DEFAULT 0 COMMENT 'indica el orden del proceso de fabricación',
  `departamento` varchar(256) DEFAULT NULL COMMENT 'Nombre del departamento',
  `asignar_numero_de_paso` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Interviene en proceso Es un paso de proceso de fabricación',
  `enviar_mensaje` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Enviar mensaje al cliente al iniciar el paso',
  `mensaje` text DEFAULT NULL COMMENT 'Mensaje para el cliente máximo 255 caracters',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha de creación',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Departamentos de la empresa con su orden en el flujo de producción. Define la secuencia de pasos de manufactura y configuración de mensajes al cliente.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departamentos`
--

LOCK TABLES `departamentos` WRITE;
/*!40000 ALTER TABLE `departamentos` DISABLE KEYS */;
INSERT INTO `departamentos` VALUES
(1,4,2,'Impresión',1,1,NULL,'2025-09-24 19:50:20'),
(2,4,3,'Estampado',1,1,NULL,'2025-09-24 19:50:20'),
(3,4,4,'Corte',1,1,NULL,'2025-09-24 19:50:20'),
(4,4,5,'Costura',1,1,NULL,'2025-09-24 19:50:20'),
(5,1,0,'Administración',0,0,NULL,'2025-09-24 19:50:20'),
(6,2,0,'Comecialización',0,0,NULL,'2025-09-24 19:50:20'),
(7,3,0,'Diseño',0,0,NULL,'2025-09-24 19:50:20'),
(8,5,0,'Producción',0,0,NULL,'2025-09-24 19:50:20');
/*!40000 ALTER TABLE `departamentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disenos`
--

DROP TABLE IF EXISTS `disenos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `disenos` (
  `_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID de la tabla',
  `id_orden` int(11) DEFAULT NULL COMMENT 'IDn de la orden',
  `id_empleado` int(11) DEFAULT NULL COMMENT 'ID del diseÑador tabla empleados',
  `id_product` int(11) DEFAULT NULL COMMENT 'ID del producto asociado al diseño',
  `origen` varchar(25) NOT NULL DEFAULT 'orden_inicial' COMMENT 'Identifica el Origen del registro, puede ser ''origen_inicial'' si se crea al momento de la facturación o ''agregado_posterior'' si proviene de la creación de una revisión',
  `codigo_diseno` varchar(6) DEFAULT NULL COMMENT 'Codigo de diseño de uso interno de 6 digitos formato XX-XXX',
  `tipo` varchar(128) DEFAULT NULL COMMENT 'Tipo de diseÑo modas ó gráfico',
  `terminado` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Indica si el diseño ya ha sido terminado',
  `linkdrive` text DEFAULT NULL COMMENT 'Link a google drive',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha de creación',
  PRIMARY KEY (`_id`),
  KEY `id_orden` (`id_orden`),
  KEY `id_empleado` (`id_empleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Registro de diseños gráficos asociados a órdenes. Almacena tipo de diseño, diseñador asignado, código interno, estado de terminación y enlace a archivos en Drive.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disenos`
--

LOCK TABLES `disenos` WRITE;
/*!40000 ALTER TABLE `disenos` DISABLE KEYS */;
/*!40000 ALTER TABLE `disenos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disenos_ajustes_y_personalizaciones`
--

DROP TABLE IF EXISTS `disenos_ajustes_y_personalizaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `disenos_ajustes_y_personalizaciones` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_orden` int(11) DEFAULT NULL COMMENT 'ID de la orden',
  `id_diseno` int(11) DEFAULT NULL COMMENT 'ID de la tabla disenos',
  `tipo` varchar(15) DEFAULT NULL COMMENT 'Si es ajuste o personalizacion',
  `cantidad` int(11) NOT NULL DEFAULT 0 COMMENT 'Cantidad de piezas trabajadas',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha de creación',
  PRIMARY KEY (`_id`),
  KEY `id_orden` (`id_orden`,`id_diseno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Registro de ajustes y personalizaciones de prendas. Almacena modificaciones solicitadas por el cliente con cantidad de piezas afectadas por cada ajuste.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disenos_ajustes_y_personalizaciones`
--

LOCK TABLES `disenos_ajustes_y_personalizaciones` WRITE;
/*!40000 ALTER TABLE `disenos_ajustes_y_personalizaciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `disenos_ajustes_y_personalizaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empleados_lotes_fabricacion`
--

DROP TABLE IF EXISTS `empleados_lotes_fabricacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleados_lotes_fabricacion` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_empleado` int(11) DEFAULT NULL COMMENT 'ID emleado que ejecuta la tarea',
  `id_departamento_creador` int(11) DEFAULT NULL,
  `id_departamento_actual` int(11) DEFAULT NULL,
  `estado` varchar(11) DEFAULT 'pendiente' COMMENT 'pendiente, en_curso, terminado',
  `fecha_inicio` timestamp NULL DEFAULT NULL COMMENT 'Fecha de inicio del pprocesamiento en lotes',
  `fecha_fin` timestamp NULL DEFAULT NULL COMMENT 'FEcha de finlización del porcesamienteo en lotes',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'FEcha de creación del registro',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='ordenes que se procesan el lotes en el modulo de Empleados';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleados_lotes_fabricacion`
--

LOCK TABLES `empleados_lotes_fabricacion` WRITE;
/*!40000 ALTER TABLE `empleados_lotes_fabricacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `empleados_lotes_fabricacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empleados_lotes_fabricacion_items`
--

DROP TABLE IF EXISTS `empleados_lotes_fabricacion_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleados_lotes_fabricacion_items` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_lote` int(11) DEFAULT NULL COMMENT 'ID del lote de fabricación',
  `id_orden` int(11) DEFAULT NULL COMMENT 'ID de la orden',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Órdenes incluidas en cada lote de fabricación. Vincula las órdenes individuales con su lote padre para procesamiento en grupo.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleados_lotes_fabricacion_items`
--

LOCK TABLES `empleados_lotes_fabricacion_items` WRITE;
/*!40000 ALTER TABLE `empleados_lotes_fabricacion_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `empleados_lotes_fabricacion_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empleados_salario`
--

DROP TABLE IF EXISTS `empleados_salario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleados_salario` (
  `id_empleado` int(11) unsigned NOT NULL COMMENT 'ID del empleado (Referencia a la tabla principal de empleados)',
  `sueldo_base` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'Salario mensual fijo antes de cualquier deducción o bono.',
  `moneda` varchar(10) NOT NULL DEFAULT 'USD' COMMENT 'Moneda en la que se paga el sueldo (ej: USD, VES).',
  `bonos_fijos` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'Monto fijo mensual o bonos regulares que forman parte del ingreso bruto.',
  `fecha_inicio_contrato` date NOT NULL COMMENT 'Fecha de inicio del contrato del empleado.',
  `pago_mensual_fijo` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 si se paga mensualmente, 0 si es quincenal o semanal.',
  `fecha_actualizacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Fecha de la última modificación.',
  PRIMARY KEY (`id_empleado`),
  KEY `idx_fecha_inicio` (`fecha_inicio_contrato`),
  KEY `idx_moneda` (`moneda`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Tabla de salarios de empleados';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleados_salario`
--

LOCK TABLES `empleados_salario` WRITE;
/*!40000 ALTER TABLE `empleados_salario` DISABLE KEYS */;
INSERT INTO `empleados_salario` VALUES
(606,600.00,'USD',50.00,'2026-01-27',1,'2026-01-27 18:53:04'),
(607,450.00,'USD',25.00,'2026-01-27',1,'2026-01-27 18:53:04'),
(608,450.00,'USD',25.00,'2026-01-27',1,'2026-01-27 18:53:04'),
(609,450.00,'USD',25.00,'2026-01-27',1,'2026-01-27 18:53:04'),
(610,450.00,'USD',25.00,'2026-01-27',1,'2026-01-27 18:53:04'),
(611,450.00,'USD',25.00,'2026-01-27',1,'2026-01-27 18:53:04'),
(612,450.00,'USD',25.00,'2026-01-27',1,'2026-01-27 18:53:04'),
(613,450.00,'USD',25.00,'2026-01-27',1,'2026-01-27 18:53:04');
/*!40000 ALTER TABLE `empleados_salario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventario`
--

DROP TABLE IF EXISTS `inventario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventario` (
  `_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificador unico',
  `sku` varchar(128) DEFAULT NULL COMMENT 'SKU del Item de inventario',
  `id_catalogo` int(11) DEFAULT NULL COMMENT 'ID de catalogo_insumos_productos',
  `tipo_insumo` enum('general','tela','tinta') DEFAULT 'general',
  `insumo` varchar(45) DEFAULT NULL COMMENT 'Nombre del insumo',
  `unidad` varchar(6) DEFAULT NULL COMMENT 'Unidd de medida del articulo CD, LTS, ML UND',
  `costo` decimal(7,2) NOT NULL DEFAULT 0.00 COMMENT 'Precio de costo del insumo',
  `rendimiento` decimal(3,1) DEFAULT NULL,
  `cantidad` decimal(7,2) NOT NULL DEFAULT 0.00 COMMENT 'Cantiad actual del insumo',
  `cantidad_inicial` decimal(7,2) NOT NULL DEFAULT 0.00 COMMENT 'Valor incial del insumo',
  `color` varchar(64) DEFAULT NULL COMMENT 'Color del insumo',
  `ancho` decimal(7,2) DEFAULT 0.00 COMMENT 'ancho del insumo',
  `elongacion` varchar(32) DEFAULT NULL COMMENT 'Elongación del material',
  `detalles` text DEFAULT NULL COMMENT 'Detalles del insumo',
  `departamento` varchar(14) DEFAULT NULL COMMENT 'Departamento al que pertence el insumo',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha de registro',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Catálogo de insumos disponibles en inventario. Almacena materiales de producción con SKU, cantidad actual e inicial, costo, unidad de medida y departamento asignado.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventario`
--

LOCK TABLES `inventario` WRITE;
/*!40000 ALTER TABLE `inventario` DISABLE KEYS */;
INSERT INTO `inventario` VALUES
(1,'PAP_001',1,'general','Papel de pruebas','Mts',20.00,1.0,205.00,250.00,'BLANCO',0.90,NULL,'Papel para pruebas de impresión','Impresión','2026-02-27 16:26:51'),
(2,'TEL_001',6,'tela','Tela de pruebas','Kg',80.00,4.0,12.75,24.00,'BLANCO',1.50,'HORIZONTAL','Tela para pruebas de estampado','Estampado','2026-02-27 16:26:51'),
(3,'TIN_C_001',4,'tinta','Tinta Cyan','ML',15.00,1.0,1000.00,1000.00,'CYAN',NULL,NULL,'Tinta cyan para impresoras','Impresión','2026-02-27 16:26:51'),
(4,'TIN_M_001',4,'tinta','Tinta Magenta','ML',15.00,1.0,1000.00,1000.00,'MAGENTA',NULL,NULL,'Tinta magenta para impresoras','Impresión','2026-02-27 16:26:51'),
(5,'TIN_Y_001',4,'tinta','Tinta Yellow','ML',15.00,1.0,1000.00,1000.00,'YELLOW',NULL,NULL,'Tinta yellow para impresoras','Impresión','2026-02-27 16:26:51'),
(6,'TIN_K_001',4,'tinta','Tinta Black','ML',15.00,1.0,1000.00,1000.00,'BLACK',NULL,NULL,'Tinta negra para impresoras','Impresión','2026-02-27 16:26:51'),
(7,'BOT_001',3,'general','Botones blancos','Und',0.50,1.0,910.00,1000.00,'BLANCO',NULL,NULL,'Botones blancos para prendas','Costura','2026-02-27 16:26:51');
/*!40000 ALTER TABLE `inventario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventario_corte`
--

DROP TABLE IF EXISTS `inventario_corte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventario_corte` (
  `_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID único del registro',
  `id_orden` int(11) NOT NULL COMMENT 'ID de la orden',
  `id_ordenes_productos` int(11) NOT NULL COMMENT 'ID del producto en ordenes_productos',
  `id_empleado_corte` int(11) DEFAULT NULL COMMENT 'ID del empleado que realizó el corte',
  `cantidad` decimal(8,2) NOT NULL DEFAULT 0.00 COMMENT 'Cantidad de piezas cortadas físicamente',
  `talla` varchar(10) DEFAULT NULL COMMENT 'Talla de la pieza cortada',
  `tela` varchar(128) DEFAULT NULL COMMENT 'Tela de la pieza cortada',
  `corte` varchar(32) DEFAULT NULL COMMENT 'Tipo de corte',
  `fecha_corte` timestamp NULL DEFAULT NULL COMMENT 'Fecha y hora real del corte',
  `estado` enum('por_cortar','cortada','disponible','procesado') NOT NULL DEFAULT 'por_cortar',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha de registro',
  PRIMARY KEY (`_id`),
  KEY `id_orden` (`id_orden`),
  KEY `estado` (`estado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Inventario de piezas cortadas listas para el siguiente departamento.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventario_corte`
--

LOCK TABLES `inventario_corte` WRITE;
/*!40000 ALTER TABLE `inventario_corte` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventario_corte` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventario_movimientos`
--

DROP TABLE IF EXISTS `inventario_movimientos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventario_movimientos` (
  `_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificador unico',
  `id_orden` int(11) DEFAULT NULL COMMENT 'ID de la  orden - lote',
  `id_producto` int(11) DEFAULT NULL COMMENT 'ID del catálogo de productos',
  `id_empleado` int(11) DEFAULT NULL COMMENT 'ID del empleado',
  `id_insumo` int(11) DEFAULT NULL COMMENT 'Id del insumoa signado',
  `id_catalogo_insumos_prodcutos` int(11) DEFAULT NULL COMMENT 'ID del catálogo seleccionado por el empleado al momento de usar el insumo',
  `id_departamento` int(11) DEFAULT NULL COMMENT 'Id del departamento del empleado',
  `departamento` varchar(20) DEFAULT NULL COMMENT 'Nombre del departamento',
  `valor_inicial` decimal(7,2) DEFAULT NULL COMMENT 'Valor inicial del insumo',
  `valor_final` decimal(7,2) DEFAULT NULL COMMENT 'Valor Final del insumo ',
  `id_reposicion` int(11) DEFAULT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'fecha del registro',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha de registro',
  PRIMARY KEY (`_id`),
  KEY `id_orden` (`id_orden`,`id_producto`,`id_empleado`,`id_insumo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Registro de movimientos de inventario de insumos. Almacena cada consumo de material vinculado a orden, producto, empleado y departamento.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventario_movimientos`
--

LOCK TABLES `inventario_movimientos` WRITE;
/*!40000 ALTER TABLE `inventario_movimientos` DISABLE KEYS */;
INSERT INTO `inventario_movimientos` VALUES
(1,1,1,607,1,NULL,1,'Impresión',250.00,235.00,NULL,'2026-02-27 16:00:53','2026-02-27 20:00:53'),
(2,1,1,608,2,NULL,2,'Estampado',24.00,20.25,NULL,'2026-02-27 16:24:36','2026-02-27 20:24:36'),
(3,1,1,610,7,NULL,4,'Costura',1000.00,910.00,NULL,'2026-02-27 16:29:23','2026-02-27 20:29:23'),
(4,2,1,608,1,NULL,1,'Impresión',220.00,205.00,NULL,'2026-02-27 16:42:25','2026-02-27 20:48:57'),
(5,2,1,608,2,NULL,2,'Estampado',16.50,12.75,NULL,'2026-02-27 16:56:15','2026-02-27 20:57:34');
/*!40000 ALTER TABLE `inventario_movimientos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventario_movimientos_historial`
--

DROP TABLE IF EXISTS `inventario_movimientos_historial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventario_movimientos_historial` (
  `_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID único del registro',
  `id_movimiento` int(11) NOT NULL COMMENT 'ID del movimiento modificado (FK a inventario_movimientos._id)',
  `campo_modificado` varchar(50) NOT NULL COMMENT 'Nombre del campo que fue modificado',
  `valor_anterior` decimal(10,2) DEFAULT NULL COMMENT 'Valor anterior del campo',
  `valor_nuevo` decimal(10,2) DEFAULT NULL COMMENT 'Valor nuevo del campo',
  `id_usuario_modificacion` int(11) NOT NULL COMMENT 'ID del usuario que realizó el cambio',
  `fecha_modificacion` datetime DEFAULT current_timestamp() COMMENT 'Fecha y hora del cambio',
  `observaciones` text DEFAULT NULL COMMENT 'Observaciones o motivo del cambio',
  PRIMARY KEY (`_id`),
  KEY `idx_movimiento` (`id_movimiento`),
  KEY `idx_fecha` (`fecha_modificacion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Historial de cambios en inventario_movimientos. Registra modificaciones de material_consumido para auditoría y trazabilidad.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventario_movimientos_historial`
--

LOCK TABLES `inventario_movimientos_historial` WRITE;
/*!40000 ALTER TABLE `inventario_movimientos_historial` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventario_movimientos_historial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventario_remanentes`
--

DROP TABLE IF EXISTS `inventario_remanentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventario_remanentes` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_insumo` int(11) NOT NULL,
  `cantidad` decimal(10,2) NOT NULL,
  `motivo` varchar(255) NOT NULL DEFAULT 'Terminación',
  `observacion` text DEFAULT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  `fecha` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`_id`),
  KEY `id_insumo` (`id_insumo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventario_remanentes`
--

LOCK TABLES `inventario_remanentes` WRITE;
/*!40000 ALTER TABLE `inventario_remanentes` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventario_remanentes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lotes`
--

DROP TABLE IF EXISTS `lotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lotes` (
  `_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID Autonumérico',
  `lote` mediumtext DEFAULT NULL COMMENT 'Código del Lote',
  `fecha` date DEFAULT NULL COMMENT 'Fecha de creación del lote',
  `id_orden` int(11) DEFAULT NULL COMMENT 'ID de la orden',
  `id_departamento_actual` int(11) DEFAULT NULL COMMENT 'ID del departamento',
  `prioridad` int(1) NOT NULL DEFAULT 0 COMMENT '0 NORMAL, 1 URGENTE',
  `piezas_actuales` int(11) DEFAULT NULL COMMENT 'Cantidad de piezasa ctuales',
  `paso` varchar(128) DEFAULT 'responsable' COMMENT 'Paso actual del proceso, Corte, estampado, impresion, etc.',
  `detalles` mediumtext DEFAULT NULL,
  `moment` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`_id`),
  KEY `id_orden` (`id_orden`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Controla el proceso de fabricacion';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lotes`
--

LOCK TABLES `lotes` WRITE;
/*!40000 ALTER TABLE `lotes` DISABLE KEYS */;
INSERT INTO `lotes` VALUES
(1,'1','2026-02-27',1,0,0,NULL,'terminado',NULL,'2026-02-27 16:33:04'),
(2,'2','2026-02-27',2,3,0,NULL,'Corte',NULL,'2026-02-27 16:33:19'),
(3,'3','2026-02-27',3,NULL,0,NULL,'producción',NULL,'2026-02-27 16:33:22'),
(4,'4','2026-02-27',4,NULL,0,NULL,'producción',NULL,'2026-02-27 16:33:24'),
(5,'5','2026-02-27',5,NULL,0,NULL,'producción',NULL,'2026-02-27 16:33:26'),
(6,'6','2026-02-27',6,NULL,0,NULL,'producción',NULL,'2026-02-27 16:33:28'),
(7,'7','2026-02-27',7,NULL,0,NULL,'producción',NULL,'2026-02-27 16:33:29'),
(8,'8','2026-02-27',8,NULL,0,NULL,'producción',NULL,'2026-02-27 16:33:32'),
(9,'9','2026-02-27',9,NULL,0,NULL,'producción',NULL,'2026-02-27 16:33:34');
/*!40000 ALTER TABLE `lotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lotes_corte_ajustes`
--

DROP TABLE IF EXISTS `lotes_corte_ajustes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lotes_corte_ajustes` (
  `_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID único del registro',
  `id_orden` int(11) NOT NULL COMMENT 'ID de la orden',
  `id_lote` int(11) DEFAULT NULL COMMENT 'ID del lote asociado (opcional)',
  `id_ordenes_productos` int(11) NOT NULL COMMENT 'ID del producto en ordenes_productos',
  `cantidad_solicitada` decimal(8,2) NOT NULL DEFAULT 0.00 COMMENT 'Cantidad original solicitada en la orden',
  `cantidad_ajustada` decimal(8,2) NOT NULL DEFAULT 0.00 COMMENT 'Cantidad nueva definida por producción',
  `id_empleado_ajuste` int(11) DEFAULT NULL COMMENT 'ID del empleado que realizó el ajuste',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha del ajuste',
  PRIMARY KEY (`_id`),
  KEY `id_orden` (`id_orden`),
  KEY `id_ordenes_productos` (`id_ordenes_productos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Registra los ajustes de cantidad a cortar definidos por producción.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lotes_corte_ajustes`
--

LOCK TABLES `lotes_corte_ajustes` WRITE;
/*!40000 ALTER TABLE `lotes_corte_ajustes` DISABLE KEYS */;
/*!40000 ALTER TABLE `lotes_corte_ajustes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lotes_detalles`
--

DROP TABLE IF EXISTS `lotes_detalles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lotes_detalles` (
  `_id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID único del registro',
  `id_orden` int(11) DEFAULT NULL COMMENT 'ID de la orden de trabajo',
  `id_woo` int(11) DEFAULT NULL COMMENT 'ID del producto en Woocommerce',
  `progreso` varchar(11) NOT NULL DEFAULT 'por iniciar' COMMENT 'Nos indica el estado de desarrollo de la tarea: por niciar, en curso, terminada',
  `id_ordenes_productos` int(11) NOT NULL DEFAULT 0 COMMENT 'ID del producto ordenes_productos',
  `id_empleado` int(11) DEFAULT NULL COMMENT 'id del empleado responsable de la producción',
  `id_reposicion` int(11) DEFAULT NULL COMMENT 'ID de en caso de ser una reposción',
  `terminado` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Indica si la tarea se ha terminado para la lista de verificación en el módulo de empleados',
  `id_departamento` int(11) DEFAULT NULL COMMENT 'ID del departamento',
  `departamento` varchar(256) DEFAULT NULL COMMENT 'Departamento al cual pertenecen las unidades, se guarda como histórico del registro en caso que el nombre del departamento sea editado posteriormente',
  `unidades_solicitadas` int(11) DEFAULT 0 COMMENT 'Unidades para el calculo de pago',
  `comision` decimal(8,2) DEFAULT 0.00 COMMENT 'Porcentaje para el cálculo de la comisión',
  `detalles` varchar(255) DEFAULT NULL COMMENT 'Información adicional del producto',
  `fecha_inicio` timestamp NULL DEFAULT NULL COMMENT 'Momento en que el primer empleado asignado ha iniciado el trabajo	',
  `fecha_terminado` timestamp NULL DEFAULT NULL COMMENT 'Momento en que el último empleado afirma haber terminado el trabajo',
  `moment` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`_id`),
  KEY `id_empleado` (`id_empleado`),
  KEY `id_orden` (`id_orden`,`id_ordenes_productos`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Controla el proceso de fabciacion x producto y empleado';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lotes_detalles`
--

LOCK TABLES `lotes_detalles` WRITE;
/*!40000 ALTER TABLE `lotes_detalles` DISABLE KEYS */;
INSERT INTO `lotes_detalles` VALUES
(1,1,1,'por iniciar',2,NULL,NULL,0,1,'Impresión',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:04'),
(2,1,1,'por iniciar',2,NULL,NULL,0,2,'Estampado',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:04'),
(3,1,1,'por iniciar',2,NULL,NULL,0,3,'Corte',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:04'),
(4,1,1,'por iniciar',2,NULL,NULL,0,4,'Costura',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:04'),
(5,1,1,'por iniciar',3,NULL,NULL,0,1,'Impresión',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:04'),
(6,1,1,'por iniciar',3,NULL,NULL,0,2,'Estampado',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:04'),
(7,1,1,'por iniciar',3,NULL,NULL,0,3,'Corte',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:04'),
(8,1,1,'por iniciar',3,NULL,NULL,0,4,'Costura',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:04'),
(9,1,1,'por iniciar',4,NULL,NULL,0,1,'Impresión',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:04'),
(10,1,1,'por iniciar',4,NULL,NULL,0,2,'Estampado',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:04'),
(11,1,1,'por iniciar',4,NULL,NULL,0,3,'Corte',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:04'),
(12,1,1,'por iniciar',4,NULL,NULL,0,4,'Costura',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:04'),
(13,2,1,'por iniciar',6,NULL,NULL,0,1,'Impresión',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:19'),
(14,2,1,'por iniciar',6,NULL,NULL,0,2,'Estampado',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:19'),
(15,2,1,'por iniciar',6,NULL,NULL,0,3,'Corte',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:19'),
(16,2,1,'por iniciar',6,NULL,NULL,0,4,'Costura',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:19'),
(17,2,1,'por iniciar',7,NULL,NULL,0,1,'Impresión',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:19'),
(18,2,1,'por iniciar',7,NULL,NULL,0,2,'Estampado',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:19'),
(19,2,1,'por iniciar',7,NULL,NULL,0,3,'Corte',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:19'),
(20,2,1,'por iniciar',7,NULL,NULL,0,4,'Costura',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:19'),
(21,2,1,'por iniciar',8,NULL,NULL,0,1,'Impresión',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:19'),
(22,2,1,'por iniciar',8,NULL,NULL,0,2,'Estampado',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:19'),
(23,2,1,'por iniciar',8,NULL,NULL,0,3,'Corte',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:19'),
(24,2,1,'por iniciar',8,NULL,NULL,0,4,'Costura',16,0.00,NULL,NULL,NULL,'2026-02-27 16:33:19'),
(25,3,1,'por iniciar',10,NULL,NULL,0,1,'Impresión',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:22'),
(26,3,1,'por iniciar',10,NULL,NULL,0,2,'Estampado',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:22'),
(27,3,1,'por iniciar',10,NULL,NULL,0,3,'Corte',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:22'),
(28,3,1,'por iniciar',10,NULL,NULL,0,4,'Costura',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:22'),
(29,3,1,'por iniciar',11,NULL,NULL,0,1,'Impresión',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:22'),
(30,3,1,'por iniciar',11,NULL,NULL,0,2,'Estampado',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:22'),
(31,3,1,'por iniciar',11,NULL,NULL,0,3,'Corte',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:22'),
(32,3,1,'por iniciar',11,NULL,NULL,0,4,'Costura',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:22'),
(33,3,1,'por iniciar',12,NULL,NULL,0,1,'Impresión',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:22'),
(34,3,1,'por iniciar',12,NULL,NULL,0,2,'Estampado',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:22'),
(35,3,1,'por iniciar',12,NULL,NULL,0,3,'Corte',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:22'),
(36,3,1,'por iniciar',12,NULL,NULL,0,4,'Costura',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:22'),
(37,4,1,'por iniciar',14,NULL,NULL,0,1,'Impresión',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:24'),
(38,4,1,'por iniciar',14,NULL,NULL,0,2,'Estampado',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:24'),
(39,4,1,'por iniciar',14,NULL,NULL,0,3,'Corte',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:24'),
(40,4,1,'por iniciar',14,NULL,NULL,0,4,'Costura',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:24'),
(41,4,1,'por iniciar',15,NULL,NULL,0,1,'Impresión',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:24'),
(42,4,1,'por iniciar',15,NULL,NULL,0,2,'Estampado',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:24'),
(43,4,1,'por iniciar',15,NULL,NULL,0,3,'Corte',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:24'),
(44,4,1,'por iniciar',15,NULL,NULL,0,4,'Costura',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:24'),
(45,4,1,'por iniciar',16,NULL,NULL,0,1,'Impresión',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:24'),
(46,4,1,'por iniciar',16,NULL,NULL,0,2,'Estampado',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:24'),
(47,4,1,'por iniciar',16,NULL,NULL,0,3,'Corte',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:24'),
(48,4,1,'por iniciar',16,NULL,NULL,0,4,'Costura',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:24'),
(49,5,1,'por iniciar',18,NULL,NULL,0,1,'Impresión',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:26'),
(50,5,1,'por iniciar',18,NULL,NULL,0,2,'Estampado',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:26'),
(51,5,1,'por iniciar',18,NULL,NULL,0,3,'Corte',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:26'),
(52,5,1,'por iniciar',18,NULL,NULL,0,4,'Costura',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:26'),
(53,5,1,'por iniciar',19,NULL,NULL,0,1,'Impresión',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:26'),
(54,5,1,'por iniciar',19,NULL,NULL,0,2,'Estampado',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:26'),
(55,5,1,'por iniciar',19,NULL,NULL,0,3,'Corte',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:26'),
(56,5,1,'por iniciar',19,NULL,NULL,0,4,'Costura',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:26'),
(57,5,1,'por iniciar',20,NULL,NULL,0,1,'Impresión',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:26'),
(58,5,1,'por iniciar',20,NULL,NULL,0,2,'Estampado',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:26'),
(59,5,1,'por iniciar',20,NULL,NULL,0,3,'Corte',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:26'),
(60,5,1,'por iniciar',20,NULL,NULL,0,4,'Costura',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:26'),
(61,6,1,'por iniciar',22,NULL,NULL,0,1,'Impresión',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:28'),
(62,6,1,'por iniciar',22,NULL,NULL,0,2,'Estampado',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:28'),
(63,6,1,'por iniciar',22,NULL,NULL,0,3,'Corte',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:28'),
(64,6,1,'por iniciar',22,NULL,NULL,0,4,'Costura',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:28'),
(65,6,1,'por iniciar',23,NULL,NULL,0,1,'Impresión',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:28'),
(66,6,1,'por iniciar',23,NULL,NULL,0,2,'Estampado',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:28'),
(67,6,1,'por iniciar',23,NULL,NULL,0,3,'Corte',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:28'),
(68,6,1,'por iniciar',23,NULL,NULL,0,4,'Costura',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:28'),
(69,6,1,'por iniciar',24,NULL,NULL,0,1,'Impresión',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:28'),
(70,6,1,'por iniciar',24,NULL,NULL,0,2,'Estampado',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:28'),
(71,6,1,'por iniciar',24,NULL,NULL,0,3,'Corte',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:28'),
(72,6,1,'por iniciar',24,NULL,NULL,0,4,'Costura',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:28'),
(73,7,1,'por iniciar',26,NULL,NULL,0,1,'Impresión',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:29'),
(74,7,1,'por iniciar',26,NULL,NULL,0,2,'Estampado',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:29'),
(75,7,1,'por iniciar',26,NULL,NULL,0,3,'Corte',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:29'),
(76,7,1,'por iniciar',26,NULL,NULL,0,4,'Costura',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:29'),
(77,7,1,'por iniciar',27,NULL,NULL,0,1,'Impresión',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:29'),
(78,7,1,'por iniciar',27,NULL,NULL,0,2,'Estampado',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:29'),
(79,7,1,'por iniciar',27,NULL,NULL,0,3,'Corte',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:29'),
(80,7,1,'por iniciar',27,NULL,NULL,0,4,'Costura',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:29'),
(81,7,1,'por iniciar',28,NULL,NULL,0,1,'Impresión',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:29'),
(82,7,1,'por iniciar',28,NULL,NULL,0,2,'Estampado',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:29'),
(83,7,1,'por iniciar',28,NULL,NULL,0,3,'Corte',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:29'),
(84,7,1,'por iniciar',28,NULL,NULL,0,4,'Costura',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:29'),
(85,8,1,'por iniciar',30,NULL,NULL,0,1,'Impresión',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:32'),
(86,8,1,'por iniciar',30,NULL,NULL,0,2,'Estampado',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:32'),
(87,8,1,'por iniciar',30,NULL,NULL,0,3,'Corte',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:32'),
(88,8,1,'por iniciar',30,NULL,NULL,0,4,'Costura',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:32'),
(89,8,1,'por iniciar',31,NULL,NULL,0,1,'Impresión',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:32'),
(90,8,1,'por iniciar',31,NULL,NULL,0,2,'Estampado',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:32'),
(91,8,1,'por iniciar',31,NULL,NULL,0,3,'Corte',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:32'),
(92,8,1,'por iniciar',31,NULL,NULL,0,4,'Costura',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:32'),
(93,8,1,'por iniciar',32,NULL,NULL,0,1,'Impresión',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:32'),
(94,8,1,'por iniciar',32,NULL,NULL,0,2,'Estampado',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:32'),
(95,8,1,'por iniciar',32,NULL,NULL,0,3,'Corte',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:32'),
(96,8,1,'por iniciar',32,NULL,NULL,0,4,'Costura',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:32'),
(97,9,1,'por iniciar',34,NULL,NULL,0,1,'Impresión',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:34'),
(98,9,1,'por iniciar',34,NULL,NULL,0,2,'Estampado',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:34'),
(99,9,1,'por iniciar',34,NULL,NULL,0,3,'Corte',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:34'),
(100,9,1,'por iniciar',34,NULL,NULL,0,4,'Costura',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:34'),
(101,9,1,'por iniciar',35,NULL,NULL,0,1,'Impresión',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:34'),
(102,9,1,'por iniciar',35,NULL,NULL,0,2,'Estampado',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:34'),
(103,9,1,'por iniciar',35,NULL,NULL,0,3,'Corte',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:34'),
(104,9,1,'por iniciar',35,NULL,NULL,0,4,'Costura',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:34'),
(105,9,1,'por iniciar',36,NULL,NULL,0,1,'Impresión',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:34'),
(106,9,1,'por iniciar',36,NULL,NULL,0,2,'Estampado',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:34'),
(107,9,1,'por iniciar',36,NULL,NULL,0,3,'Corte',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:34'),
(108,9,1,'por iniciar',36,NULL,NULL,0,4,'Costura',0,0.00,NULL,NULL,NULL,'2026-02-27 16:33:34');
/*!40000 ALTER TABLE `lotes_detalles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lotes_detalles_empleados_asignados`
--

DROP TABLE IF EXISTS `lotes_detalles_empleados_asignados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lotes_detalles_empleados_asignados` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_lotes_detalles` int(11) DEFAULT NULL COMMENT 'ID de lotes_detalles',
  `id_reposicion` int(11) DEFAULT NULL COMMENT 'ID de la reposición',
  `id_orden` int(11) DEFAULT NULL COMMENT 'ID de la orden',
  `id_empleado` int(11) DEFAULT NULL COMMENT 'ID empleado',
  `id_departamento` int(11) DEFAULT NULL COMMENT 'ID del departamento',
  `progreso` varchar(11) DEFAULT 'por iniciar' COMMENT 'Nos indica el estado de desarrollo de la tarea: por iniciar, en curso, terminada por cada empleado para el control de su proceso en el modulo de empleados',
  `procentaje_comision` decimal(8,2) NOT NULL DEFAULT 0.00 COMMENT 'Porcentaje para el cálculo de la comisión',
  `terminado` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Indica si la tarea se ha terminado para la lista de verificación en el módulo de empleados',
  `fecha_inicio` timestamp NULL DEFAULT NULL COMMENT 'Indica el momento en que el empleado indica que iniciado',
  `fecha_terminado` timestamp NULL DEFAULT NULL COMMENT 'Indica el momento en que el empleado indica que ha terminado la tarea',
  PRIMARY KEY (`_id`),
  KEY `idx_id_empleado` (`id_empleado`),
  KEY `idx_id_lotes_detalles` (`id_lotes_detalles`),
  KEY `idx_id_orden` (`id_orden`),
  KEY `idx_id_departamento` (`id_departamento`),
  KEY `idx_empleado_orden_depto` (`id_empleado`,`id_orden`,`id_departamento`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Empleados asignados a tareas de producción con su porcentaje';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lotes_detalles_empleados_asignados`
--

LOCK TABLES `lotes_detalles_empleados_asignados` WRITE;
/*!40000 ALTER TABLE `lotes_detalles_empleados_asignados` DISABLE KEYS */;
INSERT INTO `lotes_detalles_empleados_asignados` VALUES
(1,NULL,NULL,1,607,1,'terminada',100.00,0,'2026-02-27 20:00:14','2026-02-27 20:00:53'),
(3,NULL,NULL,1,608,2,'terminada',100.00,0,'2026-02-27 20:24:17','2026-02-27 20:24:36'),
(4,NULL,NULL,1,609,3,'terminada',100.00,0,'2026-02-27 20:27:18','2026-02-27 20:27:40'),
(5,NULL,NULL,1,610,4,'terminada',100.00,0,'2026-02-27 20:28:51','2026-02-27 20:29:22'),
(6,NULL,NULL,2,607,1,'terminada',20.00,0,'2026-02-27 20:41:50','2026-02-27 20:42:25'),
(7,NULL,NULL,2,608,1,'terminada',80.00,0,'2026-02-27 20:44:26','2026-02-27 20:48:57'),
(8,NULL,NULL,2,608,2,'terminada',70.00,0,'2026-02-27 20:57:10','2026-02-27 20:57:34'),
(9,NULL,NULL,2,607,2,'terminada',30.00,0,'2026-02-27 20:55:58','2026-02-27 20:56:14'),
(10,NULL,NULL,2,608,3,'por iniciar',10.00,0,NULL,NULL),
(11,NULL,NULL,2,609,3,'terminada',90.00,0,'2026-02-27 22:01:46','2026-02-27 22:01:59'),
(12,NULL,NULL,2,608,4,'por iniciar',50.00,0,NULL,NULL),
(13,NULL,NULL,2,610,4,'por iniciar',50.00,0,NULL,NULL);
/*!40000 ALTER TABLE `lotes_detalles_empleados_asignados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lotes_detalles_empleados_asignados_pausas`
--

DROP TABLE IF EXISTS `lotes_detalles_empleados_asignados_pausas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lotes_detalles_empleados_asignados_pausas` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_lotes_detalles_empleados_asignados` int(11) DEFAULT NULL,
  `pausa_inicio` timestamp NULL DEFAULT NULL,
  `pausa_fin` timestamp NULL DEFAULT NULL,
  `motivo` mediumtext NOT NULL,
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lotes_detalles_empleados_asignados_pausas`
--

LOCK TABLES `lotes_detalles_empleados_asignados_pausas` WRITE;
/*!40000 ALTER TABLE `lotes_detalles_empleados_asignados_pausas` DISABLE KEYS */;
/*!40000 ALTER TABLE `lotes_detalles_empleados_asignados_pausas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lotes_fisicos`
--

DROP TABLE IF EXISTS `lotes_fisicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lotes_fisicos` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_orden` int(11) DEFAULT NULL COMMENT 'id de la orden',
  `id_woo` int(11) DEFAULT NULL COMMENT 'id del producto en woocommerce',
  `piezas_actuales` int(11) DEFAULT NULL COMMENT 'Cantidad de unidades en el lote',
  `tela` varchar(120) DEFAULT NULL COMMENT 'Tela del corte',
  `talla` varchar(5) DEFAULT NULL COMMENT 'Nombre de la talla',
  `corte` varchar(24) DEFAULT NULL COMMENT 'Tipo de corte, dama caballeto etc',
  `categoria` int(11) DEFAULT NULL COMMENT 'ID de la categoría en woocommerce',
  `moment` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`_id`),
  KEY `id_orden` (`id_orden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Controla la cantidad de piezas cortadas existentes';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lotes_fisicos`
--

LOCK TABLES `lotes_fisicos` WRITE;
/*!40000 ALTER TABLE `lotes_fisicos` DISABLE KEYS */;
/*!40000 ALTER TABLE `lotes_fisicos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lotes_historico_solicitadas`
--

DROP TABLE IF EXISTS `lotes_historico_solicitadas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lotes_historico_solicitadas` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_orden` int(11) DEFAULT NULL COMMENT 'ID de la orden que solicitó el corte del lote',
  `id_lotes_fisicos` int(11) DEFAULT NULL,
  `unidades_produccion` int(11) DEFAULT NULL COMMENT 'Unidades que se solicitan en produccion',
  `moment` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`_id`),
  KEY `id_orden` (`id_orden`,`id_lotes_fisicos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Histórico de unidades solicitadas';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lotes_historico_solicitadas`
--

LOCK TABLES `lotes_historico_solicitadas` WRITE;
/*!40000 ALTER TABLE `lotes_historico_solicitadas` DISABLE KEYS */;
/*!40000 ALTER TABLE `lotes_historico_solicitadas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lotes_movimientos`
--

DROP TABLE IF EXISTS `lotes_movimientos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lotes_movimientos` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_lotes_detalles` int(11) DEFAULT NULL COMMENT 'ID del detalle del lote',
  `id_orden` int(11) DEFAULT NULL COMMENT 'ID de la orden',
  `unidades_existentes` int(11) DEFAULT NULL COMMENT 'unidades existentes en elote al momento de el registro',
  `unidades_solicitadas_corte` int(11) DEFAULT NULL COMMENT 'Unidades solicitadas para cortar',
  `moment` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`_id`),
  KEY `id_lotes_detalles` (`id_lotes_detalles`,`id_orden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Registra los movimientos que se efectúan sobre los lotes';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lotes_movimientos`
--

LOCK TABLES `lotes_movimientos` WRITE;
/*!40000 ALTER TABLE `lotes_movimientos` DISABLE KEYS */;
/*!40000 ALTER TABLE `lotes_movimientos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metodos_de_pago`
--

DROP TABLE IF EXISTS `metodos_de_pago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `metodos_de_pago` (
  `_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID unico de la tabla',
  `id_orden` int(11) NOT NULL DEFAULT 0 COMMENT 'ID de la orden',
  `id_caja_cierres` int(11) DEFAULT NULL COMMENT 'ID del cierre de caja, nos indica si el pago ya ha sido retirado ',
  `moneda` varchar(10) DEFAULT NULL COMMENT 'tipo de moneda',
  `metodo_pago` varchar(20) DEFAULT NULL COMMENT 'Método de pago',
  `detalle` varchar(140) DEFAULT NULL COMMENT 'Detalle en caso de que el tipo de pago sea abonos u otros',
  `tipo_de_pago` varchar(13) NOT NULL DEFAULT 'Orden nueva' COMMENT 'Procedencia del pago para identificar el tipo de ingreso',
  `monto` decimal(12,2) NOT NULL DEFAULT 0.00,
  `tasa` decimal(12,2) DEFAULT NULL,
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha de registro',
  PRIMARY KEY (`_id`),
  KEY `id_orden` (`id_orden`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Registro de transacciones de pago asociadas a órdenes. Almacena método, moneda, monto, tasa de conversión y referencia al cierre de caja.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metodos_de_pago`
--

LOCK TABLES `metodos_de_pago` WRITE;
/*!40000 ALTER TABLE `metodos_de_pago` DISABLE KEYS */;
INSERT INTO `metodos_de_pago` VALUES
(1,1,NULL,'Dólares','Efectivo','','Orden nueva',100.00,1.00,'2026-02-27 16:33:04'),
(2,2,NULL,'Dólares','Efectivo','','Orden nueva',100.00,1.00,'2026-02-27 16:33:19'),
(3,3,NULL,'Dólares','Efectivo','','Orden nueva',100.00,1.00,'2026-02-27 16:33:22'),
(4,4,NULL,'Dólares','Efectivo','','Orden nueva',100.00,1.00,'2026-02-27 16:33:24'),
(5,5,NULL,'Dólares','Efectivo','','Orden nueva',100.00,1.00,'2026-02-27 16:33:26'),
(6,6,NULL,'Dólares','Efectivo','','Orden nueva',100.00,1.00,'2026-02-27 16:33:28'),
(7,7,NULL,'Dólares','Efectivo','','Orden nueva',100.00,1.00,'2026-02-27 16:33:29'),
(8,8,NULL,'Dólares','Efectivo','','Orden nueva',100.00,1.00,'2026-02-27 16:33:32'),
(9,9,NULL,'Dólares','Efectivo','','Orden nueva',100.00,1.00,'2026-02-27 16:33:34');
/*!40000 ALTER TABLE `metodos_de_pago` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordenes`
--

DROP TABLE IF EXISTS `ordenes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordenes` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_wp` int(11) DEFAULT NULL,
  `id_wp_order` int(11) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `tipo` varchar(6) NOT NULL DEFAULT 'custom',
  `responsable` int(11) DEFAULT NULL,
  `cliente_nombre` varchar(256) DEFAULT NULL,
  `cliente_cedula` varchar(45) DEFAULT NULL,
  `lote_id` varchar(33) DEFAULT NULL,
  `fecha_inicio` varchar(45) DEFAULT NULL,
  `fecha_entrega` varchar(45) DEFAULT NULL,
  `fecha_creacion` date DEFAULT NULL,
  `token` varchar(45) DEFAULT NULL,
  `pago_descuento` decimal(12,2) NOT NULL DEFAULT 0.00,
  `pago_nota_credito` decimal(12,2) NOT NULL DEFAULT 0.00,
  `pago_total` decimal(12,2) DEFAULT 0.00,
  `pago_abono` decimal(12,2) DEFAULT 0.00,
  `pago_comision` varchar(9) NOT NULL DEFAULT 'pendiente',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha de creación',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Tabla principal de órdenes de trabajo. Almacena información del pedido: cliente, vendedor, fechas, montos, estado del proceso y comisión.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordenes`
--

LOCK TABLES `ordenes` WRITE;
/*!40000 ALTER TABLE `ordenes` DISABLE KEYS */;
INSERT INTO `ordenes` VALUES
(1,1,NULL,'terminada','custom',606,'Cliente de Pruebas','',NULL,'2026-02-27','2026-02-27','2026-02-27',NULL,0.00,0.00,390.00,100.00,'pendiente','2026-02-27 16:33:04'),
(2,1,NULL,'activa','custom',606,'Cliente de Pruebas','',NULL,'2026-02-27','2026-02-27','2026-02-27',NULL,0.00,0.00,390.00,100.00,'pendiente','2026-02-27 16:33:19'),
(3,1,NULL,'En espera','custom',606,'Cliente de Pruebas','',NULL,'2026-02-27','2026-02-27','2026-02-27',NULL,0.00,0.00,390.00,100.00,'pendiente','2026-02-27 16:33:22'),
(4,1,NULL,'En espera','custom',606,'Cliente de Pruebas','',NULL,'2026-02-27','2026-02-27','2026-02-27',NULL,0.00,0.00,390.00,100.00,'pendiente','2026-02-27 16:33:24'),
(5,1,NULL,'En espera','custom',606,'Cliente de Pruebas','',NULL,'2026-02-27','2026-02-27','2026-02-27',NULL,0.00,0.00,390.00,100.00,'pendiente','2026-02-27 16:33:26'),
(6,1,NULL,'En espera','custom',606,'Cliente de Pruebas','',NULL,'2026-02-27','2026-02-27','2026-02-27',NULL,0.00,0.00,390.00,100.00,'pendiente','2026-02-27 16:33:28'),
(7,1,NULL,'En espera','custom',606,'Cliente de Pruebas','',NULL,'2026-02-27','2026-02-27','2026-02-27',NULL,0.00,0.00,390.00,100.00,'pendiente','2026-02-27 16:33:29'),
(8,1,NULL,'En espera','custom',606,'Cliente de Pruebas','',NULL,'2026-02-27','2026-02-27','2026-02-27',NULL,0.00,0.00,390.00,100.00,'pendiente','2026-02-27 16:33:32'),
(9,1,NULL,'En espera','custom',606,'Cliente de Pruebas','',NULL,'2026-02-27','2026-02-27','2026-02-27',NULL,0.00,0.00,390.00,100.00,'pendiente','2026-02-27 16:33:34');
/*!40000 ALTER TABLE `ordenes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordenes_auditoria`
--

DROP TABLE IF EXISTS `ordenes_auditoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordenes_auditoria` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_orden` int(11) NOT NULL COMMENT 'ID de la orden',
  `accion` enum('cancelada','terminada') NOT NULL COMMENT 'Tipo de acción manual',
  `id_admin` int(11) NOT NULL COMMENT 'ID del administrador',
  `nombre_admin` varchar(255) NOT NULL COMMENT 'Nombre del administrador',
  `motivo` text NOT NULL COMMENT 'Motivo detallado',
  `fecha` datetime DEFAULT current_timestamp() COMMENT 'Fecha de la acción',
  PRIMARY KEY (`_id`),
  KEY `idx_orden` (`id_orden`),
  KEY `idx_admin` (`id_admin`),
  KEY `idx_fecha` (`fecha`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Auditoría de cancelaciones y terminaciones manuales';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordenes_auditoria`
--

LOCK TABLES `ordenes_auditoria` WRITE;
/*!40000 ALTER TABLE `ordenes_auditoria` DISABLE KEYS */;
/*!40000 ALTER TABLE `ordenes_auditoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordenes_borrador_empleado`
--

DROP TABLE IF EXISTS `ordenes_borrador_empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordenes_borrador_empleado` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_orden` int(11) DEFAULT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  `id_departamento` int(11) NOT NULL COMMENT 'ID del departamento',
  `borrador` mediumtext DEFAULT NULL COMMENT 'El detalle de la orden editado por el empleado',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha de registro',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Notas personales de empleados sobre órdenes. Permite guardar observaciones privadas por empleado y departamento.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordenes_borrador_empleado`
--

LOCK TABLES `ordenes_borrador_empleado` WRITE;
/*!40000 ALTER TABLE `ordenes_borrador_empleado` DISABLE KEYS */;
/*!40000 ALTER TABLE `ordenes_borrador_empleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordenes_fila_orden`
--

DROP TABLE IF EXISTS `ordenes_fila_orden`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordenes_fila_orden` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_orden` int(11) DEFAULT NULL COMMENT 'ID de la orden',
  `orden_fila` int(6) DEFAULT NULL COMMENT 'Orden en la fila de producción',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Cola de prioridad de órdenes de producción. Define el orden de fabricación mediante posición numérica, configurable por drag and drop.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordenes_fila_orden`
--

LOCK TABLES `ordenes_fila_orden` WRITE;
/*!40000 ALTER TABLE `ordenes_fila_orden` DISABLE KEYS */;
INSERT INTO `ordenes_fila_orden` VALUES
(1,1,1),
(2,2,2),
(3,3,3),
(4,4,4),
(5,5,5),
(6,6,6),
(7,7,7),
(8,8,8),
(9,9,9);
/*!40000 ALTER TABLE `ordenes_fila_orden` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`api_user_174`@`localhost`*/ /*!50003 TRIGGER `ordenes_fila_orden_cambios_trigger_insert`
AFTER INSERT ON `ordenes_fila_orden` FOR EACH ROW BEGIN
-- Obtiene todos los registros de ordenes_fila_orden ordenados por orden_fila
SET @cambio = (
SELECT CONCAT(
'[',
GROUP_CONCAT(
JSON_OBJECT(
'_id',
_id,
'id_orden',
id_orden,
'orden_fila',
orden_fila
)
),
']'
)
FROM ordenes_fila_orden
ORDER BY orden_fila ASC
);
-- Inserta el cambio en la tabla ordenes_fila_orden_cambios
INSERT INTO ordenes_fila_orden_cambios (cambio)
VALUES (@cambio);
-- Limpieza: mantener solo los últimos 3 registros
DELETE FROM ordenes_fila_orden_cambios
WHERE id NOT IN (
SELECT id FROM (
SELECT id FROM ordenes_fila_orden_cambios
ORDER BY fecha_cambio DESC
LIMIT 3
) AS ultimos_tres
);
END # */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`api_user_174`@`localhost`*/ /*!50003 TRIGGER `ordenes_fila_orden_cambios_trigger_update`
AFTER UPDATE ON `ordenes_fila_orden` FOR EACH ROW BEGIN
-- Obtiene todos los registros de ordenes_fila_orden ordenados por orden_fila
SET @cambio = (
SELECT CONCAT(
'[',
GROUP_CONCAT(
JSON_OBJECT(
'_id',
_id,
'id_orden',
id_orden,
'orden_fila',
orden_fila
)
),
']'
)
FROM ordenes_fila_orden
ORDER BY orden_fila ASC
);
-- Inserta el cambio en la tabla ordenes_fila_orden_cambios
INSERT INTO ordenes_fila_orden_cambios (cambio)
VALUES (@cambio);
-- Limpieza: mantener solo los últimos 3 registros
DELETE FROM ordenes_fila_orden_cambios
WHERE id NOT IN (
SELECT id FROM (
SELECT id FROM ordenes_fila_orden_cambios
ORDER BY fecha_cambio DESC
LIMIT 3
) AS ultimos_tres
);
END # */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`api_user_174`@`localhost`*/ /*!50003 TRIGGER `ordenes_fila_orden_cambios_trigger_delete`
AFTER DELETE ON `ordenes_fila_orden` FOR EACH ROW BEGIN
-- Obtiene todos los registros de ordenes_fila_orden ordenados por orden_fila
SET @cambio = (
SELECT CONCAT(
'[',
GROUP_CONCAT(
JSON_OBJECT(
'_id',
_id,
'id_orden',
id_orden,
'orden_fila',
orden_fila
)
),
']'
)
FROM ordenes_fila_orden
ORDER BY orden_fila ASC
);
-- Inserta el cambio en la tabla ordenes_fila_orden_cambios
INSERT INTO ordenes_fila_orden_cambios (cambio)
VALUES (@cambio);
-- Limpieza: mantener solo los últimos 3 registros
DELETE FROM ordenes_fila_orden_cambios
WHERE id NOT IN (
SELECT id FROM (
SELECT id FROM ordenes_fila_orden_cambios
ORDER BY fecha_cambio DESC
LIMIT 3
) AS ultimos_tres
);
END # */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `ordenes_fila_orden_cambios`
--

DROP TABLE IF EXISTS `ordenes_fila_orden_cambios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordenes_fila_orden_cambios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cambio` mediumtext NOT NULL COMMENT 'Snapshot JSON del estado de la fila',
  `fecha_cambio` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha del cambio',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Historial de cambios en la cola de prioridad. Almacena snapshots JSON del estado de la fila. Mantiene solo los últimos 3 registros mediante triggers.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordenes_fila_orden_cambios`
--

LOCK TABLES `ordenes_fila_orden_cambios` WRITE;
/*!40000 ALTER TABLE `ordenes_fila_orden_cambios` DISABLE KEYS */;
INSERT INTO `ordenes_fila_orden_cambios` VALUES
(7,'[{\"_id\": 1, \"id_orden\": 1, \"orden_fila\": 1},{\"_id\": 2, \"id_orden\": 2, \"orden_fila\": 2},{\"_id\": 3, \"id_orden\": 3, \"orden_fila\": 3},{\"_id\": 4, \"id_orden\": 4, \"orden_fila\": 4},{\"_id\": 5, \"id_orden\": 5, \"orden_fila\": 5},{\"_id\": 6, \"id_orden\": 6, \"orden_fila\": 6},{\"_id\": 7, \"id_orden\": 7, \"orden_fila\": 7}]','2026-02-27 16:33:29'),
(8,'[{\"_id\": 1, \"id_orden\": 1, \"orden_fila\": 1},{\"_id\": 2, \"id_orden\": 2, \"orden_fila\": 2},{\"_id\": 3, \"id_orden\": 3, \"orden_fila\": 3},{\"_id\": 4, \"id_orden\": 4, \"orden_fila\": 4},{\"_id\": 5, \"id_orden\": 5, \"orden_fila\": 5},{\"_id\": 6, \"id_orden\": 6, \"orden_fila\": 6},{\"_id\": 7, \"id_orden\": 7, \"orden_fila\": 7},{\"_id\": 8, \"id_orden\": 8, \"orden_fila\": 8}]','2026-02-27 16:33:32'),
(9,'[{\"_id\": 1, \"id_orden\": 1, \"orden_fila\": 1},{\"_id\": 2, \"id_orden\": 2, \"orden_fila\": 2},{\"_id\": 3, \"id_orden\": 3, \"orden_fila\": 3},{\"_id\": 4, \"id_orden\": 4, \"orden_fila\": 4},{\"_id\": 5, \"id_orden\": 5, \"orden_fila\": 5},{\"_id\": 6, \"id_orden\": 6, \"orden_fila\": 6},{\"_id\": 7, \"id_orden\": 7, \"orden_fila\": 7},{\"_id\": 8, \"id_orden\": 8, \"orden_fila\": 8},{\"_id\": 9, \"id_orden\": 9, \"orden_fila\": 9}]','2026-02-27 16:33:34');
/*!40000 ALTER TABLE `ordenes_fila_orden_cambios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordenes_fila_reposiciones`
--

DROP TABLE IF EXISTS `ordenes_fila_reposiciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordenes_fila_reposiciones` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_reposicion` int(11) DEFAULT NULL COMMENT 'ID de la reposición',
  `orden_fila` smallint(6) DEFAULT NULL COMMENT 'Orden en la fila de producción',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Cola de prioridad de reposiciones de producción. Define el orden de fabricación de reposiciones mediante posición numérica.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordenes_fila_reposiciones`
--

LOCK TABLES `ordenes_fila_reposiciones` WRITE;
/*!40000 ALTER TABLE `ordenes_fila_reposiciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `ordenes_fila_reposiciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordenes_observaciones`
--

DROP TABLE IF EXISTS `ordenes_observaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordenes_observaciones` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_orden` int(11) NOT NULL,
  `observaciones` longtext DEFAULT NULL COMMENT 'Observaciones de la orden desde QuillEditor',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Observaciones de las ordenes en html e imágenes incrustadas';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordenes_observaciones`
--

LOCK TABLES `ordenes_observaciones` WRITE;
/*!40000 ALTER TABLE `ordenes_observaciones` DISABLE KEYS */;
INSERT INTO `ordenes_observaciones` VALUES
(1,1,'<p>Pruebas onc calculos de pago</p>'),
(2,2,'<p>Pruebas onc calculos de pago</p>'),
(3,3,'<p>Pruebas onc calculos de pago</p>'),
(4,4,'<p>Pruebas onc calculos de pago</p>'),
(5,5,'<p>Pruebas onc calculos de pago</p>'),
(6,6,'<p>Pruebas onc calculos de pago</p>'),
(7,7,'<p>Pruebas onc calculos de pago</p>'),
(8,8,'<p>Pruebas onc calculos de pago</p>'),
(9,9,'<p>Pruebas onc calculos de pago</p>');
/*!40000 ALTER TABLE `ordenes_observaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordenes_productos`
--

DROP TABLE IF EXISTS `ordenes_productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordenes_productos` (
  `_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID del registro',
  `id_orden` int(11) DEFAULT NULL COMMENT 'ID de la orden',
  `id_woo` int(11) DEFAULT NULL COMMENT 'ID del producto en woocommerce',
  `id_tela` int(11) DEFAULT NULL COMMENT 'ID de la tela a utilizar del catálogo de telas',
  `id_category` int(11) NOT NULL DEFAULT 0 COMMENT 'ID de la catagoria en WooCommerce ',
  `id_products_attributes` int(11) DEFAULT NULL COMMENT 'ID de la variante del producto',
  `category_name` varchar(20) DEFAULT NULL COMMENT 'NOMBRE de la categoria en woocommerce',
  `name` varchar(240) DEFAULT NULL COMMENT 'Nombre del producto',
  `cantidad` decimal(6,1) NOT NULL DEFAULT 0.0 COMMENT 'Cantidad del producto',
  `id_size` int(11) DEFAULT NULL COMMENT 'ID de la talla',
  `talla` varchar(8) DEFAULT NULL COMMENT 'Talla del producto',
  `corte` varchar(32) DEFAULT NULL COMMENT 'Dama, caballero, niño',
  `metros` decimal(7,2) NOT NULL DEFAULT 0.00 COMMENT 'Metros de material utilizado',
  `desperdicio` decimal(7,2) NOT NULL DEFAULT 0.00 COMMENT 'Restos del material',
  `rollo` int(11) DEFAULT NULL COMMENT 'ID de el catálogo de telas',
  `tela` varchar(128) DEFAULT NULL COMMENT 'Tela principal seleccionada desde Comercialización',
  `precio_unitario` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'Precio del producto',
  `precio_woo` decimal(10,2) DEFAULT NULL COMMENT 'Precio de Woocommerce',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha de registro',
  PRIMARY KEY (`_id`),
  KEY `id_orden` (`id_orden`,`rollo`),
  KEY `id_catalogo_telas` (`rollo`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Productos incluidos en cada orden. Detalla cada ítem con cantidad, talla, corte, tela, precio unitario y categoría.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordenes_productos`
--

LOCK TABLES `ordenes_productos` WRITE;
/*!40000 ALTER TABLE `ordenes_productos` DISABLE KEYS */;
INSERT INTO `ordenes_productos` VALUES
(1,1,2,NULL,1,NULL,'Uncatagorized','Diseño Gráfico',1.0,NULL,NULL,'No aplica',0.00,0.00,NULL,'',15.00,15.00,'2026-02-27 16:33:04'),
(2,1,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,1,'S','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:04'),
(3,1,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,2,'M','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:04'),
(4,1,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,3,'L','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:04'),
(5,2,2,NULL,1,NULL,'Uncatagorized','Diseño Gráfico',1.0,NULL,NULL,'No aplica',0.00,0.00,NULL,'',15.00,15.00,'2026-02-27 16:33:19'),
(6,2,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,1,'S','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:19'),
(7,2,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,2,'M','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:19'),
(8,2,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,3,'L','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:19'),
(9,3,2,NULL,1,NULL,'Uncatagorized','Diseño Gráfico',1.0,NULL,NULL,'No aplica',0.00,0.00,NULL,'',15.00,15.00,'2026-02-27 16:33:22'),
(10,3,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,1,'S','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:22'),
(11,3,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,2,'M','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:22'),
(12,3,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,3,'L','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:22'),
(13,4,2,NULL,1,NULL,'Uncatagorized','Diseño Gráfico',1.0,NULL,NULL,'No aplica',0.00,0.00,NULL,'',15.00,15.00,'2026-02-27 16:33:24'),
(14,4,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,1,'S','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:24'),
(15,4,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,2,'M','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:24'),
(16,4,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,3,'L','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:24'),
(17,5,2,NULL,1,NULL,'Uncatagorized','Diseño Gráfico',1.0,NULL,NULL,'No aplica',0.00,0.00,NULL,'',15.00,15.00,'2026-02-27 16:33:26'),
(18,5,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,1,'S','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:26'),
(19,5,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,2,'M','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:26'),
(20,5,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,3,'L','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:26'),
(21,6,2,NULL,1,NULL,'Uncatagorized','Diseño Gráfico',1.0,NULL,NULL,'No aplica',0.00,0.00,NULL,'',15.00,15.00,'2026-02-27 16:33:28'),
(22,6,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,1,'S','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:28'),
(23,6,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,2,'M','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:28'),
(24,6,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,3,'L','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:28'),
(25,7,2,NULL,1,NULL,'Uncatagorized','Diseño Gráfico',1.0,NULL,NULL,'No aplica',0.00,0.00,NULL,'',15.00,15.00,'2026-02-27 16:33:29'),
(26,7,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,1,'S','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:29'),
(27,7,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,2,'M','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:29'),
(28,7,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,3,'L','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:29'),
(29,8,2,NULL,1,NULL,'Uncatagorized','Diseño Gráfico',1.0,NULL,NULL,'No aplica',0.00,0.00,NULL,'',15.00,15.00,'2026-02-27 16:33:32'),
(30,8,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,1,'S','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:32'),
(31,8,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,2,'M','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:32'),
(32,8,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,3,'L','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:32'),
(33,9,2,NULL,1,NULL,'Uncatagorized','Diseño Gráfico',1.0,NULL,NULL,'No aplica',0.00,0.00,NULL,'',15.00,15.00,'2026-02-27 16:33:34'),
(34,9,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,1,'S','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:34'),
(35,9,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,2,'M','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:34'),
(36,9,1,2,1,NULL,'Uncatagorized','Producto de pruebas',5.0,3,'L','Damas',0.00,0.00,NULL,'Algodon',25.00,25.00,'2026-02-27 16:33:34');
/*!40000 ALTER TABLE `ordenes_productos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordenes_tmp`
--

DROP TABLE IF EXISTS `ordenes_tmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordenes_tmp` (
  `_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Clave primaria',
  `form` longtext DEFAULT NULL COMMENT 'Datos del formulario',
  `id_empleado` int(11) DEFAULT NULL COMMENT 'ID del vendedor',
  `tipo` varchar(11) NOT NULL DEFAULT 'Orden' COMMENT 'Orden o Presupuesto',
  `moment` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Ordenes guardadas pendientes por terminar';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordenes_tmp`
--

LOCK TABLES `ordenes_tmp` WRITE;
/*!40000 ALTER TABLE `ordenes_tmp` DISABLE KEYS */;
INSERT INTO `ordenes_tmp` VALUES
(1,'{\"id\":1,\"cedula\":\"V12345678\",\"nombre\":\"Cliente\",\"apellido\":\"de Pruebas\",\"telefono\":\"584240000000\",\"email\":\"clientepruebas@email.com\",\"direccion\":\"Dirección de prueba\",\"fechaEntrega\":\"2026-02-27\",\"productos\":[{\"item\":1,\"cod\":2,\"producto\":\"Diseño Gráfico\",\"existencia\":12,\"cantidad\":\"1\",\"tela\":null,\"atributos_seleccionados\":[],\"corte\":\"No aplica\",\"talla\":null,\"colores\":[],\"xl\":0,\"categoria\":1,\"diseno\":true,\"precio\":\"15.00\",\"original_selected_price\":15},{\"item\":0,\"cod\":1,\"producto\":\"Producto de pruebas\",\"existencia\":12,\"cantidad\":\"5\",\"tela\":2,\"atributos_seleccionados\":[],\"corte\":\"Damas\",\"talla\":1,\"colores\":[],\"xl\":0,\"categoria\":1,\"diseno\":false,\"precio\":\"25.00\",\"original_selected_price\":25},{\"item\":1,\"cod\":1,\"producto\":\"Producto de pruebas\",\"existencia\":12,\"cantidad\":\"5\",\"talla\":2,\"tela\":2,\"atributos_seleccionados\":[],\"colores\":[],\"corte\":\"Damas\",\"precio\":\"25.00\",\"original_selected_price\":25,\"categoria\":1,\"diseno\":false,\"multiplicador_aplicado\":false,\"xl\":0},{\"item\":2,\"cod\":1,\"producto\":\"Producto de pruebas\",\"existencia\":12,\"cantidad\":\"5\",\"talla\":3,\"tela\":2,\"atributos_seleccionados\":[],\"colores\":[],\"corte\":\"Damas\",\"precio\":\"25.00\",\"original_selected_price\":25,\"categoria\":1,\"diseno\":false,\"multiplicador_aplicado\":false,\"xl\":0}],\"metodoDePago\":[],\"obs\":\"<p>Pruebas onc calculos de pago</p>\",\"tasaDolar\":0,\"tasaPeso\":0,\"montoDolaresEfectivo\":\"100\",\"montoDolaresEfectivoDetalle\":\"\",\"montoDolaresZelle\":0,\"montoDolaresZelleDetalle\":\"\",\"montoDolaresPanama\":0,\"montoDolaresPanamaDetalle\":\"\",\"montoPesosEfectivo\":0,\"montoPesosEfectivoDetalle\":\"\",\"montoPesosTransferencia\":0,\"montoPesosTransferenciaDetalle\":\"\",\"montoBolivaresEfectivo\":0,\"montoBolivaresEfectivoDetalle\":\"\",\"montoBolivaresPunto\":0,\"montoBolivaresPuntoDetalle\":\"\",\"montoBolivaresPagomovil\":0,\"montoBolivaresPagomovilDetalle\":\"\",\"montoBolivaresTransferencia\":0,\"montoBolivaresTransferenciaDetalle\":\"\",\"abono\":\"100.00\",\"abonoHistorico\":0,\"descuentoHistorico\":0,\"descuento\":0,\"descuentoDetalle\":\"\",\"total\":390,\"diseno_grafico\":true,\"diseno_grafico_cantidad\":1,\"diseno_modas\":false,\"diseno_modas_cantidad\":0,\"sales_commision\":true,\"next\":0,\"disableControl\":false,\"sendWhatsAppMessage\":true,\"guardarStock\":null}',606,'Orden','2026-02-26 19:48:09');
/*!40000 ALTER TABLE `ordenes_tmp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordenes_vinculadas`
--

DROP TABLE IF EXISTS `ordenes_vinculadas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordenes_vinculadas` (
  `_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id de la tabla',
  `id_father` int(11) DEFAULT NULL COMMENT 'ID de la orden principal',
  `id_child` int(11) DEFAULT NULL COMMENT 'ID de la orden secundaria',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha de registro',
  PRIMARY KEY (`_id`),
  KEY `id_father` (`id_father`,`id_child`),
  KEY `id_child` (`id_child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Relación padre-hijo entre órdenes. Permite vincular órdenes relacionadas para procesamiento y facturación conjunta.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordenes_vinculadas`
--

LOCK TABLES `ordenes_vinculadas` WRITE;
/*!40000 ALTER TABLE `ordenes_vinculadas` DISABLE KEYS */;
/*!40000 ALTER TABLE `ordenes_vinculadas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagos`
--

DROP TABLE IF EXISTS `pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pagos` (
  `_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID unico',
  `id_orden` int(11) DEFAULT NULL COMMENT 'ID de la orden',
  `id_reposicion` int(11) DEFAULT NULL COMMENT 'ID de la reposición se usa para identificar la reposición en los pagos y filtrar las reposiciones terminadas en el modulo de empleados',
  `id_departamento` int(11) DEFAULT NULL COMMENT 'ID del departamento del empleado, lo utilizamos para identificar si es reposición a cual departamento de los que tenga asignados el empleado pertenece el pago. ',
  `id_metodos_de_pago` int(11) DEFAULT NULL COMMENT 'ID de la tabla metodos_de_pago',
  `id_lotes_detalles` int(11) DEFAULT NULL COMMENT 'ID del registro asociado al pago',
  `id_empleado` int(11) DEFAULT NULL COMMENT 'ID del empleado',
  `cantidad` int(11) DEFAULT NULL COMMENT 'Cantidad de items a calcular',
  `monto_pago` decimal(12,2) DEFAULT NULL COMMENT 'Monto a pagar',
  `comision` decimal(5,2) NOT NULL DEFAULT 0.00 COMMENT 'Comision usada para el calculo del pago',
  `comision_tipo` varchar(64) DEFAULT NULL COMMENT 'Tipo de comision: fija, variable o monto fijo',
  `detalle` varchar(16) DEFAULT NULL COMMENT 'Detalle de el pago, en el caso de diseño pra diferenciar si el pago es por ajuste, personalizacion etc, en el caso de los empleados no es relevante pues es un pago unico por item trabajado registrado en la tabla id_lotes_detalles',
  `estatus` varchar(9) DEFAULT NULL COMMENT '`aprobado` es el estado por defecto, se crea al terminar la tarea desde el modulo del empleado y `rechazado` se asigna cuando hay una revision y se vuelve a asignar cuando el empleado repite la tarea',
  `fecha_pago` timestamp NULL DEFAULT NULL COMMENT 'Fecha en que se raliza el pago si es NULL no se ha realizado el pago',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha de registro',
  PRIMARY KEY (`_id`),
  KEY `id_orden` (`id_orden`,`id_metodos_de_pago`,`id_lotes_detalles`,`id_empleado`),
  KEY `id_metodos_de_pago` (`id_metodos_de_pago`),
  KEY `id_lotes_detalles` (`id_lotes_detalles`),
  KEY `id_empleado` (`id_empleado`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Registro de pagos a empleados, vendedores y diseñadores. Almacena monto, comisión, estado y fecha de pago.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagos`
--

LOCK TABLES `pagos` WRITE;
/*!40000 ALTER TABLE `pagos` DISABLE KEYS */;
INSERT INTO `pagos` VALUES
(1,1,NULL,NULL,NULL,NULL,606,NULL,5.00,5.00,'porcentaje','Comercialización','aprobado',NULL,'2026-02-27 16:33:04'),
(2,2,NULL,NULL,NULL,NULL,606,NULL,5.00,5.00,'porcentaje','Comercialización','aprobado',NULL,'2026-02-27 16:33:19'),
(3,3,NULL,NULL,NULL,NULL,606,NULL,5.00,5.00,'porcentaje','Comercialización','aprobado',NULL,'2026-02-27 16:33:22'),
(4,4,NULL,NULL,NULL,NULL,606,NULL,5.00,5.00,'porcentaje','Comercialización','aprobado',NULL,'2026-02-27 16:33:24'),
(5,5,NULL,NULL,NULL,NULL,606,NULL,5.00,5.00,'porcentaje','Comercialización','aprobado',NULL,'2026-02-27 16:33:26'),
(6,6,NULL,NULL,NULL,NULL,606,NULL,5.00,5.00,'porcentaje','Comercialización','aprobado',NULL,'2026-02-27 16:33:28'),
(7,7,NULL,NULL,NULL,NULL,606,NULL,5.00,5.00,'porcentaje','Comercialización','aprobado',NULL,'2026-02-27 16:33:29'),
(8,8,NULL,NULL,NULL,NULL,606,NULL,5.00,5.00,'porcentaje','Comercialización','aprobado',NULL,'2026-02-27 16:33:32'),
(9,9,NULL,NULL,NULL,NULL,606,NULL,5.00,5.00,'porcentaje','Comercialización','aprobado',NULL,'2026-02-27 16:33:34'),
(10,1,0,1,NULL,1,607,15,7.50,0.50,'variable','Impresión','aprobado',NULL,'2026-02-27 20:00:53'),
(11,1,NULL,2,NULL,3,608,15,9.00,0.60,'fija','Estampado','aprobado',NULL,'2026-02-27 20:24:36'),
(12,1,0,3,NULL,4,609,15,11.25,3.00,'porcentaje','Corte','aprobado',NULL,'2026-02-27 20:27:40'),
(13,1,0,4,NULL,5,610,15,7.50,0.50,'variable','Costura','aprobado',NULL,'2026-02-27 20:29:22'),
(14,2,0,1,NULL,6,607,3,1.50,0.50,'variable','Impresión','aprobado',NULL,'2026-02-27 20:42:25'),
(15,2,NULL,1,NULL,7,608,15,7.20,0.60,'fija','Impresión','aprobado',NULL,'2026-02-27 20:48:57'),
(16,2,0,2,NULL,9,607,5,2.25,0.50,'variable','Estampado','aprobado',NULL,'2026-02-27 20:56:14'),
(17,2,NULL,2,NULL,8,608,15,6.30,0.60,'fija','Estampado','aprobado',NULL,'2026-02-27 20:57:34'),
(18,2,0,3,NULL,11,609,15,10.13,3.00,'porcentaje','Corte','aprobado',NULL,'2026-02-27 22:01:59');
/*!40000 ALTER TABLE `pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagos_abonos`
--

DROP TABLE IF EXISTS `pagos_abonos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pagos_abonos` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_pago` int(11) DEFAULT NULL COMMENT 'ID de la tabla pagos',
  `monto` decimal(10,2) DEFAULT 0.00 COMMENT 'monto de la transacción',
  `descripcion` varchar(512) DEFAULT NULL COMMENT 'descripción de la transacción',
  `moment` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Registra los abonos adicionales para en el momento del pago';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagos_abonos`
--

LOCK TABLES `pagos_abonos` WRITE;
/*!40000 ALTER TABLE `pagos_abonos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pagos_abonos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagos_descuentos`
--

DROP TABLE IF EXISTS `pagos_descuentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pagos_descuentos` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_pago` int(11) DEFAULT NULL COMMENT 'ID de la tabla pagos',
  `monto` decimal(10,2) DEFAULT 0.00 COMMENT 'monto de la transacción',
  `descripcion` varchar(512) DEFAULT NULL COMMENT 'descripción de la transacción',
  `moment` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Registra los descuentos para en el momento del pago';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagos_descuentos`
--

LOCK TABLES `pagos_descuentos` WRITE;
/*!40000 ALTER TABLE `pagos_descuentos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pagos_descuentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagos_salarios`
--

DROP TABLE IF EXISTS `pagos_salarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pagos_salarios` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_pago` int(11) DEFAULT NULL COMMENT 'ID del pago',
  `tipo_salario` varchar(9) DEFAULT 'quincenal' COMMENT 'Periodo de pago del salario',
  `numero_semana` int(2) DEFAULT NULL COMMENT 'Número de la semana cancelada',
  `monto` decimal(10,2) DEFAULT NULL COMMENT 'Monto del salario cancelado',
  `moment` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Guarda los datos de los salarios cancelados';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagos_salarios`
--

LOCK TABLES `pagos_salarios` WRITE;
/*!40000 ALTER TABLE `pagos_salarios` DISABLE KEYS */;
/*!40000 ALTER TABLE `pagos_salarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `piezas_cortadas`
--

DROP TABLE IF EXISTS `piezas_cortadas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `piezas_cortadas` (
  `_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID unico',
  `id_orden` int(11) DEFAULT NULL COMMENT 'ID de la orden',
  `id_inventario` int(11) DEFAULT NULL COMMENT 'ID del insumo',
  `id_ordenes_productos` int(11) DEFAULT NULL COMMENT 'ID de los detalles de el producto cortado',
  `id_empleado` int(11) DEFAULT NULL COMMENT 'ID del empleado que hizo el corte',
  `peso` decimal(5,2) DEFAULT NULL COMMENT 'Peso en Gramos de los cortes',
  `moment` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`_id`),
  KEY `id_orden` (`id_orden`,`id_inventario`,`id_ordenes_productos`,`id_empleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Detalles de las piezas cortadas';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `piezas_cortadas`
--

LOCK TABLES `piezas_cortadas` WRITE;
/*!40000 ALTER TABLE `piezas_cortadas` DISABLE KEYS */;
/*!40000 ALTER TABLE `piezas_cortadas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `presupuestos`
--

DROP TABLE IF EXISTS `presupuestos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `presupuestos` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_wp` int(10) unsigned DEFAULT NULL COMMENT 'ID del cliente (FK a customers._id)',
  `id_wp_order` int(11) DEFAULT NULL COMMENT 'ID de la orden generada en Wocommerce',
  `status` varchar(45) DEFAULT NULL COMMENT 'Status de la orden: activa, pausada, cancelada, terminada, entregada',
  `tipo` varchar(6) NOT NULL DEFAULT 'custom' COMMENT 'Identificar si la orden pertence a custom o a sport',
  `responsable` int(11) DEFAULT NULL COMMENT 'ID del Vendedor',
  `cliente_nombre` varchar(40) DEFAULT NULL COMMENT 'Nombre del cliente',
  `cliente_cedula` varchar(45) DEFAULT NULL COMMENT 'Cedula del cliente',
  `lote_id` varchar(33) DEFAULT NULL COMMENT 'ID del Lote',
  `fecha_inicio` varchar(45) DEFAULT NULL COMMENT 'Fecha de inicio de la orden',
  `fecha_entrega` varchar(45) DEFAULT NULL COMMENT 'Fecha de entrega de la orden',
  `observaciones` longtext DEFAULT NULL COMMENT 'Detalles de la orden',
  `fecha_creacion` date DEFAULT NULL,
  `token` varchar(45) DEFAULT NULL COMMENT 'Token random',
  `pago_descuento` decimal(12,2) NOT NULL DEFAULT 0.00,
  `pago_total` decimal(12,2) DEFAULT 0.00,
  `pago_abono` decimal(12,2) DEFAULT 0.00,
  `pago_comision` varchar(9) NOT NULL DEFAULT 'pendiente' COMMENT 'Los valores puedes ser pendiente: cuando aun no se ha pagado el total de la orden al vendedor, pagado, cuando se ha  terminado de pagar la totalidad de comisiones al vendedor, anulado, cuando por algun motivo no se terminará de pagar el vanededor y el administrador decide anular los pagos de esta orden',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Creación del registro',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presupuestos`
--

LOCK TABLES `presupuestos` WRITE;
/*!40000 ALTER TABLE `presupuestos` DISABLE KEYS */;
/*!40000 ALTER TABLE `presupuestos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `presupuestos_productos`
--

DROP TABLE IF EXISTS `presupuestos_productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `presupuestos_productos` (
  `_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID del registro',
  `id_orden` int(11) DEFAULT NULL COMMENT 'ID de la orden',
  `id_woo` int(11) DEFAULT NULL COMMENT 'ID del producto en woocommerce',
  `id_category` int(11) NOT NULL DEFAULT 0 COMMENT 'ID de la catagoria en WooCommerce ',
  `category_name` varchar(20) DEFAULT NULL COMMENT 'NOMBRE de la categoria en woocommerce',
  `name` varchar(240) DEFAULT NULL COMMENT 'Nombre del producto',
  `cantidad` int(11) NOT NULL DEFAULT 0 COMMENT 'Cantidad del producto',
  `talla` varchar(8) DEFAULT NULL COMMENT 'Talla del producto',
  `corte` varchar(32) DEFAULT NULL COMMENT 'Dama, caballero, niño',
  `id_catalogo_telas` int(11) DEFAULT NULL COMMENT 'IDde el catálogo de telas',
  `tela` varchar(128) DEFAULT NULL COMMENT 'Tela principal seleccionada desde Comercialización',
  `id_products_attributes` int(11) DEFAULT NULL COMMENT 'ID de la variante del producto',
  `id_size` int(11) DEFAULT NULL COMMENT 'ID de la talla',
  `id_tela` int(11) DEFAULT NULL COMMENT 'ID de la tela a utilizar del catálogo de telas',
  `precio_unitario` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT 'Precio del producto',
  `precio_woo` decimal(10,0) DEFAULT NULL COMMENT 'Precio de Woocommerce',
  `moment` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`_id`),
  KEY `id_orden` (`id_orden`,`id_catalogo_telas`),
  KEY `id_catalogo_telas` (`id_catalogo_telas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presupuestos_productos`
--

LOCK TABLES `presupuestos_productos` WRITE;
/*!40000 ALTER TABLE `presupuestos_productos` DISABLE KEYS */;
/*!40000 ALTER TABLE `presupuestos_productos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_insumos_asignados`
--

DROP TABLE IF EXISTS `product_insumos_asignados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_insumos_asignados` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) DEFAULT NULL COMMENT 'ID del prodducto',
  `id_catalogo_insumos_productos` int(11) DEFAULT NULL COMMENT 'ID delc atalogo de insumos de productos',
  `id_departamento` int(11) NOT NULL COMMENT 'ID del departamento',
  `id_talla` int(11) DEFAULT NULL COMMENT 'ID de la talla',
  `cantidad` decimal(6,2) NOT NULL DEFAULT 0.00 COMMENT 'cantidad del insumo',
  `unidad` varchar(64) DEFAULT NULL COMMENT 'Unidad de medida del insumo',
  `tiempo` int(11) NOT NULL DEFAULT 0 COMMENT 'Tiempo estimado de fabricación en segundos',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha de registro',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Insumos requeridos por producto. Define qué materiales y cantidades necesita cada producto por departamento y talla.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_insumos_asignados`
--

LOCK TABLES `product_insumos_asignados` WRITE;
/*!40000 ALTER TABLE `product_insumos_asignados` DISABLE KEYS */;
INSERT INTO `product_insumos_asignados` VALUES
(1,1,1,1,1,1.00,'Mt',0,'2026-01-27 18:53:01'),
(2,1,1,1,2,1.00,'Mt',0,'2026-01-27 18:53:01'),
(3,1,1,1,3,1.00,'Mt',0,'2026-01-27 18:53:01'),
(4,1,1,1,4,1.00,'Mt',0,'2026-01-27 18:53:01'),
(13,1,3,4,1,6.00,'Und',0,'2026-01-27 18:53:01'),
(14,1,3,4,2,6.00,'Und',0,'2026-01-27 18:53:01'),
(15,1,3,4,3,6.00,'Und',0,'2026-01-27 18:53:01'),
(16,1,3,4,4,6.00,'Und',0,'2026-01-27 18:53:01'),
(17,1,6,2,1,1.00,'Mt',0,'2026-01-27 22:13:12'),
(18,1,6,2,2,1.00,'Mt',0,'2026-01-27 22:13:13'),
(19,1,6,2,3,1.00,'Mt',0,'2026-01-27 22:13:13'),
(20,1,6,2,4,1.00,'Mt',0,'2026-01-27 22:13:13'),
(21,0,3,1,1,1.00,'Und',0,'2026-01-28 22:02:30'),
(22,0,3,1,2,1.00,'Und',0,'2026-01-28 22:02:31'),
(23,0,3,1,3,1.00,'Und',0,'2026-01-28 22:02:31'),
(24,0,3,1,4,1.00,'Und',0,'2026-01-28 22:02:31'),
(25,6,1,1,1,0.50,'Mt',0,'2026-01-29 19:03:28'),
(26,6,1,1,2,0.60,'Mt',0,'2026-01-29 19:03:29'),
(27,6,1,1,3,0.70,'Mt',0,'2026-01-29 19:03:29'),
(28,6,1,1,4,0.80,'Mt',0,'2026-01-29 19:03:29'),
(29,7,2,2,1,1.00,'Mt',0,'2026-01-29 19:07:47'),
(30,7,2,2,2,1.00,'Mt',0,'2026-01-29 19:07:47'),
(31,7,2,2,3,1.00,'Mt',0,'2026-01-29 19:07:47'),
(32,7,2,2,4,1.00,'Mt',0,'2026-01-29 19:07:47'),
(33,7,1,1,1,1.00,'Mt',0,'2026-01-29 19:07:54'),
(34,7,1,1,2,1.00,'Mt',0,'2026-01-29 19:07:54'),
(35,7,1,1,3,1.00,'Mt',0,'2026-01-29 19:07:54'),
(36,7,1,1,4,1.00,'Mt',0,'2026-01-29 19:07:54'),
(37,8,5,1,1,1.00,'Mt',0,'2026-02-04 20:27:58'),
(38,8,5,1,2,1.00,'Mt',0,'2026-02-04 20:27:58'),
(39,8,5,1,3,1.00,'Mt',0,'2026-02-04 20:27:59'),
(40,8,5,1,4,1.00,'Mt',0,'2026-02-04 20:27:59'),
(41,8,2,2,1,1.00,'Mt',0,'2026-02-04 20:29:23'),
(42,8,2,2,2,1.00,'Mt',0,'2026-02-04 20:29:24'),
(43,8,2,2,3,1.00,'Mt',0,'2026-02-04 20:29:24'),
(44,8,2,2,4,1.00,'Mt',0,'2026-02-04 20:29:24'),
(49,9,6,2,1,1.00,'Mt',0,'2026-02-04 20:31:24'),
(50,9,6,2,2,1.00,'Mt',0,'2026-02-04 20:31:25'),
(51,9,6,2,3,1.00,'Mt',0,'2026-02-04 20:31:25'),
(52,9,6,2,4,1.00,'Mt',0,'2026-02-04 20:31:25'),
(53,10,1,1,1,1.20,'Mt',0,'2026-02-04 20:38:52'),
(54,10,1,1,2,1.20,'Mt',0,'2026-02-04 20:38:52'),
(55,10,1,1,3,1.20,'Mt',0,'2026-02-04 20:38:52'),
(56,10,1,1,4,1.20,'Mt',0,'2026-02-04 20:38:53'),
(61,10,2,2,1,1.02,'Mt',0,'2026-02-04 20:41:50'),
(62,10,2,2,2,1.02,'Mt',0,'2026-02-04 20:41:50'),
(63,10,2,2,3,1.02,'Mt',0,'2026-02-04 20:41:51'),
(64,10,2,2,4,1.02,'Mt',0,'2026-02-04 20:41:51'),
(65,4,1,1,1,1.02,'Mt',0,'2026-02-05 15:30:18'),
(66,4,1,1,2,1.02,'Mt',0,'2026-02-05 15:30:18'),
(67,4,1,1,3,1.02,'Mt',0,'2026-02-05 15:30:18'),
(68,4,1,1,4,1.02,'Mt',0,'2026-02-05 15:30:19'),
(73,3,0,1,0,0.50,'Mt',0,'2026-02-05 19:09:43'),
(74,5,0,1,0,0.50,'Mt',0,'2026-02-05 19:10:28'),
(85,5,2,2,1,1.02,'Mt',0,'2026-02-05 19:21:48'),
(86,5,2,2,2,1.02,'Mt',0,'2026-02-05 19:21:48'),
(87,5,2,2,3,1.02,'Mt',0,'2026-02-05 19:21:49'),
(88,5,2,2,4,1.02,'Mt',0,'2026-02-05 19:21:49'),
(89,5,1,1,1,1.20,'Mt',0,'2026-02-05 19:22:43'),
(90,5,1,1,2,1.20,'Mt',0,'2026-02-05 19:22:43'),
(91,5,1,1,3,1.20,'Mt',0,'2026-02-05 19:22:44'),
(92,5,1,1,4,1.20,'Mt',0,'2026-02-05 19:22:44'),
(93,4,2,2,1,1.00,'Mt',0,'2026-02-05 21:38:14'),
(94,4,2,2,2,1.00,'Mt',0,'2026-02-05 21:38:14'),
(95,4,2,2,3,1.00,'Mt',0,'2026-02-05 21:38:14'),
(96,4,2,2,4,1.00,'Mt',0,'2026-02-05 21:38:15'),
(101,11,2,2,1,1.00,'Mt',0,'2026-02-06 23:40:37'),
(102,11,2,2,2,1.00,'Mt',0,'2026-02-06 23:40:38'),
(103,11,2,2,3,1.00,'Mt',0,'2026-02-06 23:40:38'),
(104,11,2,2,4,1.00,'Mt',0,'2026-02-06 23:40:39'),
(105,11,1,1,1,1.20,'Mt',0,'2026-02-06 23:43:09'),
(106,11,1,1,2,1.20,'Mt',0,'2026-02-06 23:43:10'),
(107,11,1,1,3,1.20,'Mt',0,'2026-02-06 23:43:10'),
(108,11,1,1,4,1.20,'Mt',0,'2026-02-06 23:43:10'),
(109,9,5,1,1,2.04,'Mt',0,'2026-02-06 23:44:21'),
(110,9,5,1,2,2.04,'Mt',0,'2026-02-06 23:44:21'),
(111,9,5,1,3,2.05,'Mt',0,'2026-02-06 23:44:21'),
(112,9,5,1,4,2.05,'Mt',0,'2026-02-06 23:44:22'),
(113,6,6,2,1,1.22,'Mt',0,'2026-02-11 20:37:20'),
(114,6,6,2,2,1.23,'Mt',0,'2026-02-11 20:37:21'),
(115,6,6,2,3,1.23,'Mt',0,'2026-02-11 20:37:21'),
(116,6,6,2,4,1.23,'Mt',0,'2026-02-11 20:37:22');
/*!40000 ALTER TABLE `product_insumos_asignados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product` text DEFAULT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `fisico` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Indica true si es un [rpducto virtual como diseños, patronajes o indica si es un producto fisico, si es falso indica un producto virtual o digital',
  `es_diseno` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Indica si el producto pretenece al departamento de diseño',
  `price` decimal(20,2) DEFAULT NULL,
  `comision` decimal(7,2) DEFAULT 0.00 COMMENT 'Monto para el calculo de comisión variable',
  `stock_quantity` int(11) DEFAULT 0 COMMENT 'Existencia en inventario\r\n',
  `product_description` text DEFAULT NULL COMMENT 'Descripción para mostrar e el sistema y la teienda',
  `category_ids` varchar(255) DEFAULT NULL,
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha de registro',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Catálogo maestro de productos. Almacena productos con SKU, precio base, comisión, stock y si es producto físico o digital.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES
(1,'Producto de pruebas','PRU_01',1,0,10.00,0.20,12,'Producto de pruebas','1','2025-09-25 13:36:26'),
(2,'Diseño Gráfico','DIS_01',0,1,15.00,10.00,12,'Diseño Gráfico de pruebas','1','2025-09-25 13:36:26'),
(3,'Base banderin','pro_54',1,0,NULL,0.00,0,NULL,'1','2026-01-28 22:01:49'),
(4,'Producto de pruebas 03','PRO_PRU_03',1,0,NULL,0.00,30,NULL,'1','2026-01-29 18:37:19'),
(5,'Producto de pruebas 04','PRO_PRU_04',1,0,NULL,0.00,0,NULL,'1','2026-01-29 18:39:01'),
(6,'Producto de pruebas 05','PROD_PRU_05',1,0,NULL,0.00,15,NULL,'1','2026-01-29 19:02:43'),
(7,'Producto de pruebas 06','PRO_PRU_06',1,0,NULL,0.00,4,NULL,'1','2026-01-29 19:06:32'),
(8,'Producto de pruebas 07','PRO_PRU_07',1,0,NULL,0.00,52,NULL,'1','2026-02-04 20:22:47'),
(9,'Producto de pruebas 08','PRO_PRU_08',1,0,NULL,0.00,40,NULL,'1','2026-02-04 20:30:26'),
(10,'Producto de pruebas 09','PRO_PRU_09',1,0,NULL,0.00,29,NULL,'1','2026-02-04 20:36:23'),
(11,'FRANELA SUBLIMADA ','RQW',1,0,NULL,0.00,50,NULL,'1','2026-02-06 23:37:12');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_attributes`
--

DROP TABLE IF EXISTS `products_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_attributes` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(255) NOT NULL COMMENT 'Nombre del atributo',
  `precio` decimal(5,2) NOT NULL DEFAULT 0.00 COMMENT 'Precio del atributo',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Catálogo de atributos para productos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_attributes`
--

LOCK TABLES `products_attributes` WRITE;
/*!40000 ALTER TABLE `products_attributes` DISABLE KEYS */;
INSERT INTO `products_attributes` VALUES
(1,'Atributo de pruebas',5.00);
/*!40000 ALTER TABLE `products_attributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_attributes_values`
--

DROP TABLE IF EXISTS `products_attributes_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_attributes_values` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_orden` int(11) DEFAULT NULL COMMENT 'ID de la orden',
  `id_product` int(11) NOT NULL COMMENT 'id del prodcuto',
  `id_product_attribute` int(11) NOT NULL COMMENT 'id del atributo del producto',
  `attribute_value` varchar(128) NOT NULL COMMENT 'Descripción del atributo del producto',
  `attribute_price` decimal(7,2) NOT NULL DEFAULT 0.00 COMMENT 'Precio del atributo',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Atributos asignados a los productos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_attributes_values`
--

LOCK TABLES `products_attributes_values` WRITE;
/*!40000 ALTER TABLE `products_attributes_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_attributes_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_comisiones`
--

DROP TABLE IF EXISTS `products_comisiones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_comisiones` (
  `_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID único',
  `id_product` int(11) DEFAULT NULL COMMENT 'ID del producto',
  `id_departamento` int(11) DEFAULT NULL COMMENT 'ID del departamento',
  `comision` decimal(5,2) NOT NULL DEFAULT 0.00 COMMENT 'Comisión asignada',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Comisiones asignada a los productos por departamento';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_comisiones`
--

LOCK TABLES `products_comisiones` WRITE;
/*!40000 ALTER TABLE `products_comisiones` DISABLE KEYS */;
INSERT INTO `products_comisiones` VALUES
(1,1,1,0.50),
(2,1,2,0.50),
(3,1,3,0.50),
(4,1,4,0.50),
(5,1,6,0.50),
(6,1,7,0.50);
/*!40000 ALTER TABLE `products_comisiones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_prices`
--

DROP TABLE IF EXISTS `products_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_prices` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) DEFAULT NULL COMMENT 'ID del producto',
  `price` decimal(7,2) DEFAULT NULL COMMENT 'Precio del producto',
  `descripcion` varchar(128) DEFAULT NULL COMMENT 'Descripción del precio',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Precios de productos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_prices`
--

LOCK TABLES `products_prices` WRITE;
/*!40000 ALTER TABLE `products_prices` DISABLE KEYS */;
INSERT INTO `products_prices` VALUES
(1,1,25.00,'Detal'),
(2,1,22.00,'Mayor'),
(3,2,15.00,'Unitario'),
(4,3,33.00,'Precio full'),
(5,4,12.00,'Detal'),
(6,5,15.00,'Detal'),
(7,6,30.00,'Detal'),
(8,7,5.00,'Detal'),
(9,8,22.00,'Detal'),
(10,9,55.00,'Detal'),
(11,10,12.00,'unico'),
(12,11,0.10,'Detal');
/*!40000 ALTER TABLE `products_prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_sizes_eficiencia`
--

DROP TABLE IF EXISTS `products_sizes_eficiencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_sizes_eficiencia` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_size` int(11) DEFAULT NULL COMMENT 'ID de la talla',
  `id_catalogo_insumos_prodcutos` int(11) DEFAULT NULL COMMENT 'ID de la tabla catalogo_insumos_productos',
  `cantidad` decimal(3,2) NOT NULL DEFAULT 0.00 COMMENT 'Cantidad de insumo',
  `unidad` varchar(64) DEFAULT NULL COMMENT 'Unidad de medida del insumo',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Eficiencia de insumos por talla. Define la cantidad de material requerido para cada talla de producto.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_sizes_eficiencia`
--

LOCK TABLES `products_sizes_eficiencia` WRITE;
/*!40000 ALTER TABLE `products_sizes_eficiencia` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_sizes_eficiencia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_tiempos_de_produccion`
--

DROP TABLE IF EXISTS `products_tiempos_de_produccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_tiempos_de_produccion` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) DEFAULT NULL COMMENT 'ID del producto',
  `id_departamento` int(11) DEFAULT NULL COMMENT 'ID del departamento',
  `tiempo` int(11) NOT NULL DEFAULT 1 COMMENT 'Tiempo de producción en segundos',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha de registro',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Tiempos estándar de producción. Define minutos estimados por producto y departamento para proyección de entregas.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_tiempos_de_produccion`
--

LOCK TABLES `products_tiempos_de_produccion` WRITE;
/*!40000 ALTER TABLE `products_tiempos_de_produccion` DISABLE KEYS */;
INSERT INTO `products_tiempos_de_produccion` VALUES
(1,1,1,180,'2026-01-27 18:53:01'),
(2,1,2,144,'2026-01-27 18:53:01'),
(3,1,3,240,'2026-01-27 18:53:01'),
(4,1,4,360,'2026-01-27 18:53:01'),
(5,7,1,180,'2026-01-29 19:07:02'),
(6,7,2,144,'2026-01-29 19:07:26'),
(7,6,1,180,'2026-01-29 19:08:22'),
(8,8,1,180,'2026-02-04 20:28:16'),
(9,8,2,144,'2026-02-04 20:28:24'),
(10,9,1,180,'2026-02-04 20:30:47'),
(11,9,2,144,'2026-02-04 20:31:09'),
(12,10,1,180,'2026-02-04 20:36:33'),
(13,10,2,144,'2026-02-04 20:39:02'),
(14,3,1,180,'2026-02-05 19:09:42'),
(15,5,1,84,'2026-02-05 19:10:28'),
(16,5,2,198,'2026-02-05 19:21:47'),
(17,4,1,720,'2026-02-05 21:38:13'),
(18,4,2,720,'2026-02-05 21:38:14'),
(19,4,3,180,'2026-02-06 17:44:09'),
(20,4,4,300,'2026-02-06 17:44:16'),
(21,5,3,150,'2026-02-06 17:44:59'),
(22,5,4,240,'2026-02-06 17:45:09'),
(23,11,1,84,'2026-02-06 23:40:34'),
(24,11,2,198,'2026-02-06 23:40:34'),
(25,11,3,150,'2026-02-06 23:40:35'),
(26,11,4,240,'2026-02-06 23:40:35'),
(27,6,2,144,'2026-02-20 19:38:58'),
(28,3,2,144,'2026-02-20 19:40:58'),
(29,3,3,240,'2026-02-20 19:40:58'),
(30,3,4,360,'2026-02-20 19:40:59'),
(31,6,3,240,'2026-02-20 19:41:24'),
(32,6,4,360,'2026-02-20 19:41:24'),
(33,7,3,240,'2026-02-20 19:43:45'),
(34,7,4,360,'2026-02-20 19:43:46'),
(35,8,3,240,'2026-02-20 19:44:10'),
(36,8,4,360,'2026-02-20 19:44:10'),
(37,9,3,240,'2026-02-20 19:44:32'),
(38,9,4,360,'2026-02-20 19:44:33'),
(39,10,3,240,'2026-02-20 19:44:58'),
(40,10,4,360,'2026-02-20 19:44:58');
/*!40000 ALTER TABLE `products_tiempos_de_produccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rendimiento`
--

DROP TABLE IF EXISTS `rendimiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `rendimiento` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_empleado_impresion` int(11) DEFAULT NULL,
  `id_empleado_estampado` int(11) DEFAULT NULL,
  `id_empleado_corte` int(11) DEFAULT NULL,
  `id_orden` int(11) DEFAULT NULL,
  `id_insumo` int(11) DEFAULT NULL COMMENT 'Numero de rollo',
  `metros` decimal(7,2) NOT NULL DEFAULT 0.00 COMMENT 'Metros de material utilizado',
  `desperdicio` decimal(7,2) NOT NULL DEFAULT 0.00 COMMENT 'peso en gramos del material sobrante',
  `moment` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Datos para el calculo de el rendimiento del material';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rendimiento`
--

LOCK TABLES `rendimiento` WRITE;
/*!40000 ALTER TABLE `rendimiento` DISABLE KEYS */;
INSERT INTO `rendimiento` VALUES
(1,NULL,NULL,609,1,NULL,0.00,0.14,'2026-02-27 20:27:40'),
(2,NULL,NULL,609,2,NULL,0.00,0.05,'2026-02-27 22:01:59');
/*!40000 ALTER TABLE `rendimiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reposiciones`
--

DROP TABLE IF EXISTS `reposiciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reposiciones` (
  `_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID unico de la tabla',
  `id_orden` int(11) DEFAULT NULL COMMENT 'ID de la orden',
  `id_departamento` int(11) DEFAULT NULL COMMENT 'ID del departamento del empleado al que se envía la reposición',
  `id_departamento_solicitante` int(11) DEFAULT NULL COMMENT 'ID del departamento que emitió la reposición',
  `id_empleado` int(11) DEFAULT NULL COMMENT 'ID del empleado asignado',
  `id_empleado_emisor` int(11) DEFAULT NULL COMMENT 'ID del empleado que genera la reposición',
  `id_ordenes_productos` int(11) DEFAULT NULL COMMENT 'ID de ordenes_productos',
  `unidades` int(11) DEFAULT NULL COMMENT 'Número de unidades involucradas en la reposición',
  `detalle` text DEFAULT NULL COMMENT 'Detalles del jefe de producción',
  `detalle_emisor` text DEFAULT NULL COMMENT 'Detalle de el empleado emisor',
  `aprobada` tinyint(1) DEFAULT 0 COMMENT 'Determina si la reposición has sido aprobada es true, si no es false, si en null aún no se ha indicado el estado de la reposicion',
  `terminada` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Indica si el empleado al que se le asignó la reposicion ya la terminó',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'moment',
  PRIMARY KEY (`_id`),
  KEY `id_orden` (`id_orden`,`id_empleado`,`id_ordenes_productos`),
  KEY `id_empleado_emisor` (`id_empleado_emisor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Control de reposiciones durante el proceso de fabricacion';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reposiciones`
--

LOCK TABLES `reposiciones` WRITE;
/*!40000 ALTER TABLE `reposiciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `reposiciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `retiros`
--

DROP TABLE IF EXISTS `retiros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `retiros` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_empleado` int(11) DEFAULT NULL,
  `monto` decimal(10,0) DEFAULT NULL,
  `moneda` varchar(12) DEFAULT NULL COMMENT 'nombre de la moneda que será objeto del retiro',
  `tasa` decimal(10,0) NOT NULL DEFAULT 0 COMMENT 'TASA DE CONVERSION',
  `metodo_pago` varchar(20) DEFAULT NULL COMMENT 'Metodo de pago ejm pago movil, efectivo etc.',
  `detalle_retiro` text DEFAULT NULL,
  `cierre_caja` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'El registro corresponde a un cierre de caja',
  `moment` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`_id`),
  KEY `id_empleado` (`id_empleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `retiros`
--

LOCK TABLES `retiros` WRITE;
/*!40000 ALTER TABLE `retiros` DISABLE KEYS */;
/*!40000 ALTER TABLE `retiros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisiones`
--

DROP TABLE IF EXISTS `revisiones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisiones` (
  `_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id de la tabla',
  `id_orden` int(11) DEFAULT NULL COMMENT 'ID de la orden a la cual pertenece el diseño y estarevision',
  `id_diseno` int(11) DEFAULT NULL COMMENT 'id en la tabla disenos',
  `id_empleado` int(11) DEFAULT NULL COMMENT 'ID del diseñador que envió la revisión',
  `id_product` int(11) DEFAULT NULL COMMENT 'ID del producto asociado a la revisión',
  `tipo` varchar(128) DEFAULT NULL COMMENT 'Tipo de diseño asociado a la revisión',
  `revision` int(11) NOT NULL DEFAULT 0 COMMENT 'Numero de revisiones máximo dos',
  `estatus` varchar(19) NOT NULL DEFAULT 'Esperando Respuesta' COMMENT 'Los estados son ''Esperando Respuesta'', ''Rechazado'', ''Aprobado''',
  `url_image` varchar(255) DEFAULT NULL COMMENT 'URL de la imagen de la revisión',
  `detalles` text DEFAULT NULL COMMENT 'Detalles de la revision',
  `moment` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha de registro',
  PRIMARY KEY (`_id`),
  KEY `id_orden` (`id_orden`,`id_diseno`),
  KEY `id_orden_2` (`id_orden`,`id_diseno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Control de revisiones de diseño. Registra cada iteración de revisión solicitada al diseñador con límite máximo de dos.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisiones`
--

LOCK TABLES `revisiones` WRITE;
/*!40000 ALTER TABLE `revisiones` DISABLE KEYS */;
/*!40000 ALTER TABLE `revisiones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salario_carga_familiar`
--

DROP TABLE IF EXISTS `salario_carga_familiar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `salario_carga_familiar` (
  `id_carga` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID único del registro de carga familiar.',
  `id_empleado` int(11) unsigned NOT NULL COMMENT 'ID del empleado asociado a la carga familiar.',
  `nombre_completo` varchar(100) NOT NULL COMMENT 'Nombre completo del familiar.',
  `cedula_o_id` varchar(20) DEFAULT NULL COMMENT 'Cédula o ID del familiar.',
  `tipo_relacion` varchar(50) NOT NULL COMMENT 'Tipo de relación con el empleado (hijo, esposa, padre, etc).',
  `fecha_nacimiento` date NOT NULL COMMENT 'Fecha de nacimiento del dependiente para verificar edad límite para deducciones.',
  `es_deducible_impuesto` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 si califica como deducción fiscal según las leyes locales.',
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Fecha de registro en el sistema.',
  PRIMARY KEY (`id_carga`),
  KEY `idx_empleado` (`id_empleado`),
  KEY `idx_tipo_relacion` (`tipo_relacion`),
  KEY `idx_fecha_nacimiento` (`fecha_nacimiento`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Tabla de carga familiar para deducciones fiscales de empleados';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salario_carga_familiar`
--

LOCK TABLES `salario_carga_familiar` WRITE;
/*!40000 ALTER TABLE `salario_carga_familiar` DISABLE KEYS */;
INSERT INTO `salario_carga_familiar` VALUES
(1,607,'Nombre de ejemplo',NULL,'Hijo','2015-03-15',1,'2026-01-27 18:53:04'),
(2,607,'María Pérez',NULL,'Hija','2018-07-22',1,'2026-01-27 18:53:04'),
(3,608,'José González',NULL,'Cónyuge','1988-03-22',1,'2026-01-27 18:53:04'),
(4,610,'Miguel Martínez',NULL,'Hijo','2012-11-10',1,'2026-01-27 18:53:04'),
(5,611,'Antonio Fernández',NULL,'Padre','1960-09-05',0,'2026-01-27 18:53:04');
/*!40000 ALTER TABLE `salario_carga_familiar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sizes`
--

DROP TABLE IF EXISTS `sizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sizes` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL COMMENT 'Nombre de la talla',
  `variation_percentage` decimal(5,2) DEFAULT 0.00 COMMENT 'Porcentaje de variación para cálculo de insumos',
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Catálogo de tallas disponibles. Define las tallas manejadas por la empresa para asignación en productos y órdenes.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sizes`
--

LOCK TABLES `sizes` WRITE;
/*!40000 ALTER TABLE `sizes` DISABLE KEYS */;
INSERT INTO `sizes` VALUES
(1,'S',2.00),
(2,'M',2.20),
(3,'L',2.30),
(4,'XL',2.40);
/*!40000 ALTER TABLE `sizes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tinta_filtro`
--

DROP TABLE IF EXISTS `tinta_filtro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tinta_filtro` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_inventario` int(11) DEFAULT NULL COMMENT 'Id del insumo',
  `color` varchar(1) NOT NULL COMMENT 'Color de la tinta C, M, Y, K, W',
  `moment` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Indica cuales insumos son tintas para filtrar las tintas';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tinta_filtro`
--

LOCK TABLES `tinta_filtro` WRITE;
/*!40000 ALTER TABLE `tinta_filtro` DISABLE KEYS */;
INSERT INTO `tinta_filtro` VALUES
(1,3,'C','2026-01-27 18:53:01'),
(2,4,'M','2026-01-27 18:53:01'),
(3,5,'Y','2026-01-27 18:53:01'),
(4,6,'K','2026-01-27 18:53:01');
/*!40000 ALTER TABLE `tinta_filtro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tintas`
--

DROP TABLE IF EXISTS `tintas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tintas` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `c` decimal(7,2) DEFAULT NULL COMMENT 'Cyan',
  `m` decimal(7,2) DEFAULT NULL COMMENT 'Magenta',
  `y` decimal(7,2) DEFAULT NULL COMMENT 'Yellow',
  `k` decimal(7,2) DEFAULT NULL COMMENT 'Black',
  `w` decimal(7,2) DEFAULT NULL COMMENT 'White',
  `id_catalogo_impresoras` int(11) DEFAULT NULL COMMENT 'ID del catálogo de impresoras',
  `id_orden` int(11) DEFAULT NULL COMMENT 'Id de la Orden',
  `id_empleado` int(11) DEFAULT NULL COMMENT 'ID del empleado que imprimió',
  `moment` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Registra el consumo de tintas por orden';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tintas`
--

LOCK TABLES `tintas` WRITE;
/*!40000 ALTER TABLE `tintas` DISABLE KEYS */;
INSERT INTO `tintas` VALUES
(1,3.30,3.50,4.10,3.10,NULL,1,1,607,'2026-02-27 20:00:53'),
(2,4.10,4.20,4.50,4.00,NULL,1,2,607,'2026-02-27 20:42:25'),
(3,4.20,5.70,3.10,6.00,NULL,1,2,608,'2026-02-27 20:48:57');
/*!40000 ALTER TABLE `tintas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tintas_recargas`
--

DROP TABLE IF EXISTS `tintas_recargas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tintas_recargas` (
  `_id` int(11) NOT NULL AUTO_INCREMENT,
  `id_insumo` int(11) DEFAULT NULL,
  `id_catalogo_impresora` int(11) DEFAULT NULL COMMENT 'ID catalodo de imoresoras',
  `color` varchar(1) DEFAULT NULL COMMENT 'Color de la tinta',
  `cantidad` decimal(7,2) DEFAULT NULL COMMENT 'Cantidad en ML',
  `fecha_recarga` timestamp NULL DEFAULT NULL COMMENT 'Fecha de la recarga',
  `moment` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci COMMENT='Recargas de tinta';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tintas_recargas`
--

LOCK TABLES `tintas_recargas` WRITE;
/*!40000 ALTER TABLE `tintas_recargas` DISABLE KEYS */;
/*!40000 ALTER TABLE `tintas_recargas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-01 15:32:55
